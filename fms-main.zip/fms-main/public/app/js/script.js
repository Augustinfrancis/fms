// Popup Model
var popupModel = document.getElementById("popupModel");

var filterModel = document.getElementById("filterModel");

var deleteModel = document.getElementById("deleteModel");

var creditOptionsModel = document.getElementById("creditOptionsModel");

var savingModel = document.getElementById("savingModel");

var navModel = document.getElementById("navModel");

var previewModel = document.getElementById("previewModel");

var infoModel = document.getElementById("infoModel");

function openPopup() {
  popupModel.style.display = "block";
}

function openFilter() {
  filterModel.style.display = "block";
}

function openDeleteDialog() {
  deleteModel.style.display = "block";
}

function closeDeleteDialog() {
  deleteModel.style.display = "none";
}

function openOptionsModel() {
  creditOptionsModel.style.display = "block";
}

function openNavModel() {
  navModel.style.display = "block";
}

function openPreviewModel() {
  previewModel.style.display = "block";
}

function closePreviewModel() {
  previewModel.style.display = "none";
}

function opensavingModel(id, day, amount, date) {
  savingModel.style.display = "block";

  document.getElementById("savingsDay").innerHTML = "(Day " + day + ")";
  document.getElementById("savingsAmount").innerHTML = amount;
  document.getElementById("savingsDate").innerHTML = date;
  document
    .getElementById("savingsLink")
    .setAttribute(
      "href",
      "s_index.html?id=" +
        id +
        "&day=" +
        day +
        "&amount=" +
        amount +
        "&date=" +
        date
    );
}

function openinfoModel(heading, content) {
  infoModel.style.display = "block";

  document.getElementById("info_heading").innerHTML = heading;
  document.getElementById("info_para").innerHTML = content;
}

window.onclick = function (event) {
  if (event.target == popupModel) {
    popupModel.style.display = "none";
  }
  if (event.target == filterModel) {
    filterModel.style.display = "none";
  }
  if (event.target == deleteModel) {
    deleteModel.style.display = "none";
  }
  if (event.target == creditOptionsModel) {
    creditOptionsModel.style.display = "none";
  }
  if (event.target == savingModel) {
    savingModel.style.display = "none";
  }
  if (event.target == navModel) {
    navModel.style.display = "none";
  }
  if (event.target == previewModel) {
    previewModel.style.display = "none";
  }
  if (event.target == infoModel) {
    infoModel.style.display = "none";
  }
};

const searchTransaction = () => {
  let filter = document.getElementById("searchTxn").value.toLowerCase();

  let txnContainer = document.getElementById("txnContainer");

  let txnItem = txnContainer.getElementsByClassName("txn_item");

  for (var i = 0; i < txnItem.length; i++) {
    let a = txnItem[i].getElementsByTagName("h4")[0];

    let textValue = a.textContent || a.innerHTML;

    if (textValue.toLowerCase().indexOf(filter) > -1) {
      txnItem[i].style.display = "block";
    } else {
      txnItem[i].style.display = "none";
    }
  }
};

const searchCustomer = () => {
  let filterCus = document.getElementById("searchCus").value.toLowerCase();

  let CusContainer = document.getElementById("CusContainer");

  let CusItem = CusContainer.getElementsByTagName("a");

  for (var i = 0; i < CusItem.length; i++) {
    let a = CusItem[i].getElementsByTagName("h4")[0];

    let textValue = a.textContent || a.innerHTML;

    if (textValue.toLowerCase().indexOf(filterCus) > -1) {
      CusItem[i].style.display = "block";
    } else {
      CusItem[i].style.display = "none";
    }
  }
};

const calcMode1 = () => {
  let goal_interval_amount = document.getElementById("goal_interval_amount");

  document.getElementById("total_goal_amount").value =
    goal_interval_amount.value * 52;

  function add_weeks(dt, n) {
    var addedDate = new Date(dt.setDate(dt.getDate() + n * 7));

    let year = addedDate.getFullYear();

    if (addedDate.getMonth() < 10) {
      var month = Number("0" + addedDate.getMonth()) + 1;
    } else {
      var month = Number(addedDate.getMonth()) + 1;
    }

    if (addedDate.getDate() < 10) {
      var weekdate = "0" + addedDate.getDate();
    } else {
      var weekdate = addedDate.getDate();
    }

    return year + "-" + month + "-" + weekdate;
  }

  document.getElementById("goal_end_date").value = add_weeks(
    new Date(document.getElementById("mode1StartDate").value),
    52
  );
};

const calcMode2 = () => {
  let input_goal_amount = document.getElementById("total_goal_amount").value;

  let input_interval_unit = document
    .getElementById("interval_unit")
    .value.toLowerCase();

  let input_start_date = document.getElementById("start_date").value;

  let input_end_date = document.getElementById("end_date").value;

  var date1 = new Date(input_start_date);

  var date2 = new Date(input_end_date);

  var difference_time = date2.getTime() - date1.getTime();

  if (input_interval_unit == "daily") {
    var difference_value = 1 + difference_time / (1000 * 60 * 60 * 24);
    total_amount_save = Math.ceil(input_goal_amount / difference_value);
    document
      .getElementById("goal_interval_amount")
      .setAttribute(
        "value",
        total_amount_save + "/day - x" + difference_value + " days"
      );
  } else if (input_interval_unit == "weekly") {
    var difference_value =
      Math.floor(difference_time / (1000 * 60 * 60 * 24 * 7)) + 1;
    var total_amount_save = Math.ceil(input_goal_amount / difference_value);
    document
      .getElementById("goal_interval_amount")
      .setAttribute(
        "value",
        total_amount_save + "/week - x" + difference_value + " weeks"
      );
  } else if (input_interval_unit == "monthly") {
    function getMonthDifference(startDate, endDate) {
      return (
        endDate.getMonth() -
        startDate.getMonth() +
        12 * (endDate.getFullYear() - startDate.getFullYear()) +
        1
      );
    }
    var difference_value = getMonthDifference(date1, date2);
    total_amount_save = Math.ceil(input_goal_amount / difference_value);
    document
      .getElementById("goal_interval_amount")
      .setAttribute(
        "value",
        total_amount_save + "/month - x" + difference_value + " months"
      );
  } else if (input_interval_unit == "yearly") {
    var diff_years = date2.getFullYear() - date1.getFullYear() + 1;

    total_amount_save = Math.ceil(input_goal_amount / diff_years);
    document
      .getElementById("goal_interval_amount")
      .setAttribute(
        "value",
        total_amount_save + "/year - x" + diff_years + " years"
      );
  }
};

const calcMode3 = () => {
  let input_intervel_amount = Math.round(
    document.getElementById("goal_interval_amount").value
  );

  let input_interval_unit = document
    .getElementById("interval_unit")
    .value.toLowerCase();

  let input_start_date = document.getElementById("start_date").value;

  let input_end_date = document.getElementById("end_date").value;

  var date1 = new Date(input_start_date);

  var date2 = new Date(input_end_date);

  var difference_time = date2.getTime() - date1.getTime();

  if (input_interval_unit == "daily") {
    var difference_value = 1 + difference_time / (1000 * 60 * 60 * 24);
    var total_amount_save = Math.ceil(difference_value * input_intervel_amount);
    document
      .getElementById("total_goal_amount")
      .setAttribute(
        "value",
        total_amount_save + " in " + difference_value + " days"
      );
  } else if (input_interval_unit == "weekly") {
    var difference_value =
      Math.floor(difference_time / (1000 * 60 * 60 * 24 * 7)) + 1;
    var total_amount_save = Math.ceil(input_intervel_amount * difference_value);
    document
      .getElementById("total_goal_amount")
      .setAttribute(
        "value",
        total_amount_save + " in " + difference_value + " weeks"
      );
  } else if (input_interval_unit == "monthly") {
    function getMonthDifference(startDate, endDate) {
      return (
        endDate.getMonth() -
        startDate.getMonth() +
        12 * (endDate.getFullYear() - startDate.getFullYear()) +
        1
      );
    }
    var difference_value = getMonthDifference(date1, date2);
    total_amount_save = Math.ceil(difference_value * input_intervel_amount);
    document
      .getElementById("total_goal_amount")
      .setAttribute(
        "value",
        total_amount_save + " in " + difference_value + " months"
      );
  } else if (input_interval_unit == "yearly") {
    var difference_value = date2.getFullYear() - date1.getFullYear() + 1;
    total_amount_save = Math.ceil(difference_value * input_intervel_amount);
    document
      .getElementById("total_goal_amount")
      .setAttribute(
        "value",
        total_amount_save + " in " + difference_value + " years"
      );
  }
};
