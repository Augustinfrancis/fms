<?php
include "db/conn.php";

$user_lent_sum_query = mysqli_query($connection, "SELECT SUM(credit_amount) as lent_total FROM credit WHERE credit_user_id = $golspoh_session_user_id AND credit_type = 'lent'");
$user_lent_sum_row = mysqli_fetch_array($user_lent_sum_query);
$user_lent_sum = $user_lent_sum_row['lent_total'];

$user_debt_sum_query = mysqli_query($connection, "SELECT SUM(credit_amount) as debt_total FROM credit WHERE credit_user_id = $golspoh_session_user_id AND credit_type = 'debt'");
$user_debt_sum_row = mysqli_fetch_array($user_debt_sum_query);
$user_debt_sum = $user_debt_sum_row['debt_total'];

$user_total_bal = $user_lent_sum - $user_debt_sum;

if(empty($user_lent_sum)){
    $user_lent_sum = 0;
}
if(empty($user_debt_sum)){
    $user_debt_sum = 0;
}

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>Finance Management System - Credits</title>

        <!-- Fontawesome -->
        <!-- <link rel="stylesheet" href="../../fontawesome/css/all.min.css" /> -->

        <!-- Boxicons -->
        <link href="https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css" rel="stylesheet" />

        <!-- Google Fonts -->
        <!-- Livvic -->
        <link href="https://fonts.googleapis.com/css2?family=Livvic:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,900&display=swap" rel="stylesheet" />

        <!-- Style -->
        <link rel="stylesheet" href="css/style.css" />
    </head>
    <body>
        <?php
if(isset($_GET['page'])){
    $page = $_GET['page'];
?>
<div class="bg_container">
    <div class="bg_curve small">
        <div class="profile_top">
            <div class="profile_left">
                <div class="profile_icon"></div>
                <div class="profile_content">
                    <h5>Welcome back,</h5>
                    <h3><?php echo $user_name; ?></h3>
                </div>
            </div>
            <div class="menu_icon" onclick="openNavModel()">
                <i class="bx bx-menu"></i>
            </div>
        </div>
    </div>
</div>
<?php
}else{
    $page = "";
        ?>
        <div class="bg_container">
            <div class="bg_curve">
                <div class="profile_top">
                    <div class="profile_left">
                        <div class="profile_icon"></div>
                        <div class="profile_content">
                            <h5>Welcome back,</h5>
                            <h3><?php echo $user_name; ?></h3>
                        </div>
                    </div>
                    <div class="menu_icon" onclick="openNavModel()">
                        <i class="bx bx-menu"></i>
                    </div>
                </div>
            </div>
        </div>
        <?php
}
?>

<?php

switch ($page) {
    case 'add_customer':
        include 'includes/credit/add_customer.php';
        break;
    case 'customer':
        include 'includes/credit/customer.php';
        break;
    case 'credit_info':
        include 'includes/credit/credit_info.php';
        break;
    case 'add_credit':
        include 'includes/credit/add_credit.php';
        break;
    default:
?>
        <!-- Balance Starts -->
        <section class="balance_containner">
            <div class="designs_container">
                <div class="rings_container">
                    <div class="ring_item"></div>
                    <div class="ring_item"></div>
                    <div class="ring_item"></div>
                    <i class="bx bx-money"></i>
                </div>
                <div class="curves"></div>
            </div>
            <div class="content_continer">
                <p>Balance</p>
                <h1><?php echo $user_currency . $user_total_bal; ?></h1>
                <div class="red_green_container">
                    
                        <div class="box red">
                            <p><i class="bx bxs-up-arrow-circle"></i> Debt</p>
                            <h2><?php echo $user_currency . $user_debt_sum; ?></h2>
                        </div>
                    
                    
                        <div class="box green">
                            <p><i class="bx bxs-down-arrow-circle"></i> Lent</p>
                            <h2><?php echo $user_currency . $user_lent_sum; ?></h2>
                        </div>
                    
                </div>
            </div>
        </section>
        <!-- Balance Ends -->
        <div class="big_body_holder">
        <!-- List Starts -->

        <section class="txn_container">
            <div class="txn_heading">
                <h3>Customers</h3>
            </div>
            <div class="search_container">
                <div class="search_holder">
                    <div class="field">
                        <input type="text" id="searchCus" onkeyup="searchCustomer()" placeholder="Search Customers" />
                    </div>
                    <div class="icon">
                        <i class="bx bx-search-alt-2"></i>
                    </div>
                </div>
            </div>
            <div class="txn_content" id="CusContainer">
                <?php

$select_credit_customer_query = "SELECT * FROM credit_customers WHERE credit_customers_user_id = $golspoh_session_user_id";
$select_credit_customer_result = mysqli_query($connection, $select_credit_customer_query);
while($row = mysqli_fetch_assoc($select_credit_customer_result)){
    $credit_customers_id = $row['credit_customers_id'];
    $credit_customers_name = $row['credit_customers_name'];

    $select_recent_credit_query = "SELECT * FROM credit WHERE credit_user_id = $golspoh_session_user_id AND credit_cus_id = $credit_customers_id";
    $select_recent_credit_result = mysqli_query($connection, $select_recent_credit_query);
    $select_recent_credit_rows_count = mysqli_num_rows($select_recent_credit_result);
    // $select_recent_credit_rows = mysqli_fetch_assoc($select_recent_credit_result);
    while($row = mysqli_fetch_assoc($select_recent_credit_result)){
        $credit_amount = $row['credit_amount'];
        $credit_type = $row['credit_type'];
    }

                ?>
                <a href="credit.php?page=customer&id=<?php echo $credit_customers_id; ?>" id="CusItem">
                    <div class="txn_item">
                        <div class="txn_inside">
                            <div class="txn_icon">
                                <i class="bx bxs-wallet-alt"></i>
                            </div>
                            <div class="txn_text">
                                <h4><?php echo $credit_customers_name; ?></h4>
                                <span><?php 
                                if($select_recent_credit_rows_count >= 1){
                                    echo $user_currency . $credit_amount. " " . $credit_type;
                                }else{
                                    echo "No Credits";
                                }
                                ?></span>
                            </div>
                            <div class="txn_amount">
                                <?php
$user_total_lent = mysqli_fetch_array(mysqli_query($connection, "SELECT SUM(credit_amount) as user_lent_total FROM credit WHERE credit_user_id = $golspoh_session_user_id AND credit_type = 'lent' AND credit_cus_id = '$credit_customers_id'"));
$user_total_lent_sum = $user_total_lent['user_lent_total'];

$user_total_debt = mysqli_fetch_array(mysqli_query($connection, "SELECT SUM(credit_amount) as user_debt_total FROM credit WHERE credit_user_id = $golspoh_session_user_id AND credit_type = 'debt' AND credit_cus_id = '$credit_customers_id'"));
$user_total_debt_sum = $user_total_debt['user_debt_total'];

$total_user_total = $user_total_lent_sum - $user_total_debt_sum;

if($total_user_total < 0){
    echo "<p class='red'>$user_currency$total_user_total <i class='bx bxs-up-arrow-circle'></i></p>";
}elseif($total_user_total > 0){
    echo "<p class='green'>$user_currency$total_user_total <i class='bx bxs-down-arrow-circle'></i></p>";
}else{
    echo "<p style='color:#222;'>$user_currency$total_user_total</p>";
}
                                ?>
                            </div>
                        </div>
                    </div>
                </a>
                <?php
}
                ?>
            </div>
        </section>

</div>
        <!-- List End -->
        <!-- Add btn starts -->
        <a href="credit.php?page=add_customer">
            <button class="btn popupbtn filled"><i class="bx bxs-user-plus"></i> Add Customer</button>
        </a>
        <!-- Add btn ends -->
<?php
break;
}
?>
<?php
include "includes/nav.php";
?>
        <script src="js/script.js"></script>
    </body>
</html>
