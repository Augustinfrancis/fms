<?php
include 'db/conn.php';

$select_all_saving_goals_query = "SELECT * FROM savings WHERE savings_user_id = $golspoh_session_user_id";
$select_all_saving_goals_result = mysqli_query($connection, $select_all_saving_goals_query);
while($row = mysqli_fetch_assoc($select_all_saving_goals_result)){
    $savings_id = $row['savings_id'];
    $savings_amount = $row['savings_amount'];
    $savings_amount_interval = $row['savings_amount_interval'];
    $savings_unit_interval = $row['savings_intervar_unit'];
    $savings_title = $row['savings_title'];
    $savings_category = $row['savings_category'];
    $savings_date = $row['savings_date'];
    $savings_start_date = $row['savings_start_date'];
    $savings_end_date = $row['savings_end_date'];

    // $select_all_goal_record_query = "SELECT * FROM savings_history WHERE savings_history_user_id = $golspoh_session_user_id AND savings_history_goal_id = $savings_id";
    // $select_all_goal_record_result = mysqli_query($connection, $select_all_goal_record_query);
    // while($row = mysqli_fetch_assoc($select_all_goal_record_result)){
    //     $savings_history_id = $row['savings_history_id'];
    //     $savings_history_amount = $row['savings_history_amount'];
    //     $savings_history_title = $row['savings_history_title'];
    //     $savings_history_category = $row['savings_history_category'];
    //     $savings_history_date = $row['savings_history_date'];
    // }

    if($savings_category == "52-week Challenge"){
        // $sum = 0;
        // $total_amount = 0;
        // for($i = 1; $i <= 52; $i++){
        //     $sum = $sum + $i;
        //     $total_amount = $total_amount + ($sum * 5);
            
        //     if($savings_history_amount == $total_amount){
        //         echo "week: " . $i . " - " . $sum .". saving: ". $sum * 5 .".bank: ".$total_amount."(paid)<br>";
        //     }else{
        //         echo "week: " . $i . " - " . $sum .". saving: ". $sum * 5 .".bank: ".$total_amount."(not paid)<br>";
        //     }
        // }
        
        // echo "Total: ".$total_amount;
    }elseif($savings_category == "Target Amount Challenge"){
        $differece_time = strtotime($savings_end_date) - strtotime($savings_start_date);

        if($savings_unit_interval == "daily"){
            $differece_value = 1 + $differece_time / (60 * 60 * 24);

            $goal_daily_count_query = mysqli_query($connection, "SELECT * FROM savings_history WHERE savings_history_user_id = $golspoh_session_user_id AND savings_history_goal_id = $savings_id");
            $goal_daily_count_rows = mysqli_num_rows($goal_daily_count_query);
            $goal_result = mysqli_fetch_assoc($goal_daily_count_query);

            print_r($goal_result);

            $age = array();
            for($i = 1; $i <= $differece_value; $i++){
                $age[$i] = date("d-m-Y", strtotime($savings_start_date . "+".$i."days"));
            }

            foreach($age as $check_date => $x_value) {
                if(strtotime($x_value) <= strtotime($current_date)){
                    echo "day=" . $check_date . ", date=" . $x_value;
                    echo "<br>";
                }
            }
            
        }elseif($savings_unit_interval == "weekly"){
            $differece_value = round($differece_time / (60 * 60 * 24 * 7));
        }elseif($savings_unit_interval == "monthly"){
            $differece_value = round($differece_time / (60 * 60 * 24 * 30));
        }elseif($savings_unit_interval == "yearly"){
            $differece_value = round($differece_time / (60 * 60 * 24 * 365));
        }
    }
}
?>