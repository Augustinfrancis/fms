-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 02, 2023 at 03:44 AM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fms`
--

-- --------------------------------------------------------

--
-- Table structure for table `credit`
--

CREATE TABLE `credit` (
  `credit_id` int(11) NOT NULL,
  `credit_user_id` int(11) NOT NULL,
  `credit_cus_id` int(11) NOT NULL,
  `credit_amount` varchar(255) NOT NULL,
  `credit_date` varchar(255) NOT NULL,
  `credit_time` varchar(255) NOT NULL,
  `credit_type` varchar(255) NOT NULL,
  `credit_file` text NOT NULL,
  `credit_description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `credit_customers`
--

CREATE TABLE `credit_customers` (
  `credit_customers_id` int(11) NOT NULL,
  `credit_customers_user_id` int(11) NOT NULL,
  `credit_customers_name` varchar(255) NOT NULL,
  `credit_customers_phone` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `savings`
--

CREATE TABLE `savings` (
  `savings_id` int(11) NOT NULL,
  `savings_user_id` int(11) NOT NULL,
  `savings_amount` varchar(50) NOT NULL,
  `savings_amount_interval` varchar(255) NOT NULL,
  `savings_interval_unit` varchar(255) NOT NULL,
  `savings_title` varchar(255) NOT NULL,
  `savings_category` varchar(255) NOT NULL,
  `savings_date` varchar(255) NOT NULL,
  `savings_start_date` varchar(255) NOT NULL,
  `savings_end_date` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `savings_history`
--

CREATE TABLE `savings_history` (
  `savings_history_id` int(11) NOT NULL,
  `savings_history_user_id` int(11) NOT NULL,
  `savings_history_amount` varchar(50) NOT NULL,
  `savings_history_title` varchar(255) NOT NULL,
  `savings_history_category` varchar(255) NOT NULL,
  `savings_history_date` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `trans`
--

CREATE TABLE `trans` (
  `trans_id` int(11) NOT NULL,
  `trans_user_id` int(11) NOT NULL,
  `trans_purpose` varchar(255) NOT NULL,
  `trans_icon_code` varchar(50) NOT NULL,
  `trans_category` varchar(50) NOT NULL,
  `trans_amount` varchar(255) NOT NULL,
  `trans_type` varchar(255) NOT NULL,
  `trans_date` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `credit`
--
ALTER TABLE `credit`
  ADD PRIMARY KEY (`credit_id`);

--
-- Indexes for table `credit_customers`
--
ALTER TABLE `credit_customers`
  ADD PRIMARY KEY (`credit_customers_id`);

--
-- Indexes for table `savings`
--
ALTER TABLE `savings`
  ADD PRIMARY KEY (`savings_id`);

--
-- Indexes for table `savings_history`
--
ALTER TABLE `savings_history`
  ADD PRIMARY KEY (`savings_history_id`);

--
-- Indexes for table `trans`
--
ALTER TABLE `trans`
  ADD PRIMARY KEY (`trans_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `credit`
--
ALTER TABLE `credit`
  MODIFY `credit_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `credit_customers`
--
ALTER TABLE `credit_customers`
  MODIFY `credit_customers_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `savings`
--
ALTER TABLE `savings`
  MODIFY `savings_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `savings_history`
--
ALTER TABLE `savings_history`
  MODIFY `savings_history_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `trans`
--
ALTER TABLE `trans`
  MODIFY `trans_id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
