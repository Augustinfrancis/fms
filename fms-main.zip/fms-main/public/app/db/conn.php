<?php
ob_start();
session_start();
date_default_timezone_set('Asia/Kolkata');
$current_date = date('d-m-Y');
$current_time = date('h:i:s a');
$current_date_time = $current_date . ' ' . $current_time;
$connection = mysqli_connect("localhost", "root", "", "fms");

if(!$connection){
    echo "Database Not Connected";
}else{
    $golspoh_session_user_id = 1;
    $user_name = "Yugendiran";
    $user_currency = "&#8377;";
}

?>