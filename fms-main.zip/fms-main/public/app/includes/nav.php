<!-- Navigation Bar Starts -->
<div class="nav_model" id="navModel">
    <div class="nav_container">
        <div class="nav_container_inside">
            <a href="index.php">
                <button style="width: 60%" class="btn center filled">Dashboard</button>
            </a>
            <a href="transaction.php">
                <button style="width: 60%" class="btn center filled">Transactions</button>
            </a>
            <a href="credit.php">
                <button style="width: 60%" class="btn center filled">Credits</button>
            </a>
            <a href="saving.php">
                <button style="width: 60%" class="btn center filled">Savings</button>
            </a>
            <a href="budget.php">
                <button style="width: 60%" class="btn center filled">Budget Planer</button>
            </a>
            <a href="settings.php">
                <button style="width: 60%" class="btn center filled">Settings</button>
            </a>
        </div>
    </div>
</div>
<!-- Navigation Bar Ends -->