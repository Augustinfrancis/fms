<!-- Page Heading Starts -->
<div class="page_heading">
    <a href="transaction.php">
        <div class="back_btn">
            <i class="bx bx-chevron-left"></i>
        </div>
    </a>
    <?php
if(isset($_GET['type'])){
    $get_type = $_GET['type'];
    if($get_type == 'income'){
        echo "<div class='heading green'>Choose Income Source</div>";
    }else{
        echo "<div class='heading red'>Choose Income Source</div>";
    }
}else{
    header('location: transaction.php');
}
    ?>
    
</div>
<!-- Page Heading Ends -->

<div class="small_body_holder">
<!-- Icons Starts -->
<section class="icon_container">
    <h3>Expenses:</h3>
    <div class="icon_items">
        <a href="transaction.php?page=form&type=<?php echo $get_type; ?>&category=bill&icon=bx bxs-credit-card">
            <div class="icons_item">
                <div class="icon"><i class='bx bxs-credit-card' ></i></div>
                <p>Bill</p>
            </div>
        </a>
        <a href="transaction.php?page=form&type=<?php echo $get_type; ?>&category=clothing&icon=bx bxs-t-shirt">
            <div class="icons_item">
                <div class="icon"><i class='bx bxs-t-shirt' ></i></div>
                <p>Clothing</p>
            </div>
        </a>
        <a href="transaction.php?page=form&type=<?php echo $get_type; ?>&category=education&icon=bx bxs-book">
            <div class="icons_item">
                <div class="icon"><i class='bx bxs-book'></i></div>
                <p>Education</p>
            </div>
        </a>
        <a href="transaction.php?page=form&type=<?php echo $get_type; ?>&category=electronics&icon=bx bx-chip">
            <div class="icons_item">
                <div class="icon"><i class='bx bx-chip' ></i></div>
                <p>Electronics</p>
            </div>
        </a>
        <a href="transaction.php?page=form&type=<?php echo $get_type; ?>&category=entertainment&icon=bx bx-slideshow">
            <div class="icons_item">
                <div class="icon"><i class='bx bx-slideshow' ></i></div>
                <p>Entertainment</p>
            </div>
        </a>
        <a href="transaction.php?page=form&type=<?php echo $get_type; ?>&category=food&icon=bx bx-food-menu">
            <div class="icons_item">
                <div class="icon"><i class='bx bx-food-menu' ></i></div>
                <p>Food</p>
            </div>
        </a>
        <a href="transaction.php?page=form&type=<?php echo $get_type; ?>&category=health&icon=bx bxs-heart">
            <div class="icons_item">
                <div class="icon"><i class='bx bxs-heart'></i></div>
                <p>Health</p>
            </div>
        </a>
        <a href="transaction.php?page=form&type=<?php echo $get_type; ?>&category=insurance&icon=bx bxs-donate-heart">
            <div class="icons_item">
                <div class="icon"><i class='bx bxs-donate-heart'></i></div>
                <p>Insurance</p>
            </div>
        </a>
        <a href="transaction.php?page=form&type=<?php echo $get_type; ?>&category=vehicle&icon=bx bx-car">
            <div class="icons_item">
                <div class="icon"><i class='bx bx-car'></i></div>
                <p>Vehicle</p>
            </div>
        </a>
        <a href="transaction.php?page=form&type=<?php echo $get_type; ?>&category=shopping&icon=bx bx-cart">
            <div class="icons_item">
                <div class="icon"><i class='bx bx-cart'></i></div>
                <p>Shopping</p>
            </div>
        </a>
        <a href="transaction.php?page=form&type=<?php echo $get_type; ?>&category=social&icon=bx bxs-city">
            <div class="icons_item">
                <div class="icon"><i class='bx bxs-city'></i></div>
                <p>Social</p>
            </div>
        </a>
        <a href="transaction.php?page=form&type=<?php echo $get_type; ?>&category=sports&icon=bx bx-tennis-ball">
            <div class="icons_item">
                <div class="icon"><i class='bx bx-tennis-ball'></i></div>
                <p>Sport</p>
            </div>
        </a>
        <a href="transaction.php?page=form&type=<?php echo $get_type; ?>&category=tax&icon=bx bxs-bank">
            <div class="icons_item">
                <div class="icon"><i class='bx bxs-bank'></i></div>
                <p>Tax</p>
            </div>
        </a>
        <a href="transaction.php?page=form&type=<?php echo $get_type; ?>&category=fines&icon=bx bx-wallet">
            <div class="icons_item">
                <div class="icon"><i class='bx bx-wallet' ></i></div>
                <p>Fines</p>
            </div>
        </a>
        <a href="transaction.php?page=form&type=<?php echo $get_type; ?>&category=mobile&icon=bx bx-mobile-alt">
            <div class="icons_item">
                <div class="icon"><i class='bx bx-mobile-alt'></i></div>
                <p>Mobile</p>
            </div>
        </a>
        <a href="transaction.php?page=form&type=<?php echo $get_type; ?>&category=dateing&icon=bx bx-calendar-heart">
            <div class="icons_item">
                <div class="icon"><i class='bx bx-calendar-heart'></i></div>
                <p>Dateing</p>
            </div>
        </a>
        <a href="transaction.php?page=form&type=<?php echo $get_type; ?>&category=transportation&icon=bx bx-bus">
            <div class="icons_item">
                <div class="icon"><i class='bx bx-bus'></i></div>
                <p>Transportation</p>
            </div>
        </a>
        <a href="transaction.php?page=form&type=<?php echo $get_type; ?>&category=subscription&icon=bx bx-wallet-alt">
            <div class="icons_item">
                <div class="icon"><i class='bx bx-wallet-alt'></i></div>
                <p>Subscription</p>
            </div>
        </a>
    </div>

    <h3>Incomes:</h3>
    <div class="icon_items">
        <a href="transaction.php?page=form&type=<?php echo $get_type; ?>&category=awards&icon=bx bx-award">
            <div class="icons_item">
                <div class="icon"><i class='bx bx-award'></i></div>
                <p>Awards</p>
            </div>
        </a>
        <a href="transaction.php?page=form&type=<?php echo $get_type; ?>&category=coupons&icon=bx bxs-coupon">
            <div class="icons_item">
                <div class="icon"><i class='bx bxs-coupon' ></i></div>
                <p>Coupons</p>
            </div>
        </a>
        <a href="transaction.php?page=form&type=<?php echo $get_type; ?>&category=grants&icon=bx bx-dollar">
            <div class="icons_item">
                <div class="icon"><i class='bx bx-dollar'></i></div>
                <p>Grants</p>
            </div>
        </a>
        <a href="transaction.php?page=form&type=<?php echo $get_type; ?>&category=refunds&icon=bx bx-revision">
            <div class="icons_item">
                <div class="icon"><i class='bx bx-revision' ></i></div>
                <p>Refunds</p>
            </div>
        </a>
        <a href="transaction.php?page=form&type=<?php echo $get_type; ?>&category=rental&icon=bx bx-coin-stack">
            <div class="icons_item">
                <div class="icon"><i class='bx bx-coin-stack'></i></div>
                <p>Rental</p>
            </div>
        </a>
        <a href="transaction.php?page=form&type=<?php echo $get_type; ?>&category=salary&icon=bx bx-money">
            <div class="icons_item">
                <div class="icon"><i class='bx bx-money'></i></div>
                <p>Salary</p>
            </div>
        </a>
        <a href="transaction.php?page=form&type=<?php echo $get_type; ?>&category=sale&icon=bx bx-cart-alt">
            <div class="icons_item">
                <div class="icon"><i class='bx bx-cart-alt' ></i></div>
                <p>Sale</p>
            </div>
        </a>
        <a href="transaction.php?page=form&type=<?php echo $get_type; ?>&category=sale&icon=bx bxs-bank">
            <div class="icons_item">
                <div class="icon"><i class='bx bxs-bank'></i></div>
                <p>Deposits</p>
            </div>
        </a>
    </div>
</section>
<!-- Icons Ends -->
<br><br><br><br>
</div>