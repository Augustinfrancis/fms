<!-- Page Heading Starts -->
<div class="page_heading">
    <a href="transaction.php">
        <div class="back_btn">
            <i class="bx bx-chevron-left"></i>
        </div>
    </a>
    <div class="heading red"><i class="bx bxs-up-arrow-circle"></i> Expense</div>
    <div class="filter_btn" onclick="openFilter()"><i class="bx bx-filter-alt"></i></div>
</div>
<!-- Page Heading Ends -->
<div class="small_body_holder">
<!-- List Starts -->
<section class="txn_container">
    <div class="search_container">
        <div class="search_holder">
            <div class="field">
                <input type="text" id="searchTxn" onkeyup="searchTransaction()" placeholder="Search Transaction" />
            </div>
            <div class="icon">
                <i class="bx bx-search-alt-2"></i>
            </div>
        </div>
    </div>
    <div class="txn_content" id="txnContainer">
    <?php

$select_recent_transaction_query = "SELECT * FROM trans WHERE trans_user_id = $golspoh_session_user_id AND trans_type='expense' ORDER BY trans_id DESC";
$select_recent_transaction_result = mysqli_query($connection, $select_recent_transaction_query);
while($row = mysqli_fetch_assoc($select_recent_transaction_result)){
    $trans_id = $row['trans_id'];
    $trans_user_id = $row['trans_user_id'];
    $trans_purpose = $row['trans_purpose'];
    $trans_icon_code = $row['trans_icon_code'];
    $trans_category = $row['trans_category'];
    $trans_amount = $row['trans_amount'];
    $trans_type = $row['trans_type'];
    $trans_date = strtotime($row['trans_date']);
    $mod_date = date("d/m/Y", $trans_date);

    if(isset($_GET['filterfrom']) && isset($_GET['filterto'])){
        $startdate = strtotime($_GET['filterfrom']);
        $enddate = strtotime($_GET['filterto']);

        if($startdate <= $trans_date && $trans_date <= $enddate) {
            ?>
        <div class="txn_item">
            <div class="txn_inside">
                <div class="txn_icon">
                    <i class="<?php echo $trans_icon_code; ?>"></i>
                </div>
                <div class="txn_text">
                    <h4><?php echo $trans_purpose; ?></h4>
                    <span><?php echo $trans_category; ?></span>
                </div>
                <div class="txn_amount">
                    <?php
if($trans_type == 'income'){
echo "<p class='green'>+ $user_currency$trans_amount <i class='bx bxs-down-arrow-circle'></i></p>";
}else{
echo "<p class='red'>- $user_currency$trans_amount <i class='bx bxs-up-arrow-circle'></i></p>";
}
                    ?>
                    <span><?php echo $mod_date; ?></span>
                </div>
            </div>
            <a href="transaction.php?page=<?php echo $page; ?>&deleteid=<?php echo $trans_id; ?>"><div class="txn_delete_btn">
                <i class='bx bxs-trash'></i>
            </div></a>
        </div>
            <?php
        }
    }else{    
        ?>
        <div class="txn_item">
            <div class="txn_inside">
                <div class="txn_icon">
                    <i class="<?php echo $trans_icon_code; ?>"></i>
                </div>
                <div class="txn_text">
                    <h4><?php echo $trans_purpose; ?></h4>
                    <span><?php echo $trans_category; ?></span>
                </div>
                <div class="txn_amount">
                    <?php
if($trans_type == 'income'){
echo "<p class='green'>+ $user_currency$trans_amount <i class='bx bxs-down-arrow-circle'></i></p>";
}else{
echo "<p class='red'>- $user_currency$trans_amount <i class='bx bxs-up-arrow-circle'></i></p>";
}
                    ?>
                    <span><?php echo $mod_date; ?></span>
                </div>
            </div>
            <a href="transaction.php?page=<?php echo $page; ?>&deleteid=<?php echo $trans_id; ?>"><div class="txn_delete_btn">
                <i class='bx bxs-trash'></i>
            </div></a>
        </div>
        <?php
}
}
        ?>
    </div>
</section>
<!-- List End -->
<br><br><br><br>
</div>