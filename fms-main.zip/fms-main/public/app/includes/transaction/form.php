<?php
if(isset($_GET['type']) && isset($_GET['category']) && $_GET['icon']){
    $get_type = $_GET['type'];
    $get_category = $_GET['category'];
    $get_icon = $_GET['icon'];
}else{
    header('location: transaction.php');
}
?>
<!-- Page Heading Starts -->
<div class="page_heading">
    <a href="transaction.php?page=category&type=<?php echo $get_type;?>">
        <div class="back_btn">
            <i class="bx bx-chevron-left"></i>
        </div>
    </a>
    <?php
if($get_type == 'income'){
    echo "<div class='heading green'><i class='bx bxs-down-arrow-circle'></i> Add Income</div>";
}else{
    echo "<div class='heading red'><i class='bx bxs-up-arrow-circle'></i> Add Expense</div>";
}
    ?>
</div>
<!-- Page Heading Ends -->
<div class="small_body_holder">
<!-- Form Section Starts -->
<section class="amount_section">
    <form action="transaction.php?page=form&type=<?php echo $get_type; ?>&category=<?php echo $get_category; ?>&icon=<?php echo $get_icon; ?>" method="post">
        <div class="amount_input_container">
            <p>Enter Amount:</p>
            <span><?php echo $user_currency; ?></span>
            <div class="input_container">
                <input name="amount" type="number" required placeholder="0" />
            </div>
        </div>
        <div class="search_container">
            <div class="search_holder">
                <div class="field">
                    <input type="text" name="purpose" placeholder="Txn Name" required />
                </div>
            </div>
        </div>
        <button type="submit" name="submit" class="btn stroke center"><i class="bx bx-plus-medical"></i> Add Income</button>
    </form>
</section>
<!-- Form Section Ends -->

<?php
if(isset($_POST['submit'])){
    $txn_amount = $_POST['amount'];
    $txn_purpose = $_POST['purpose'];

    $txn_amount = mysqli_real_escape_string($connection, $txn_amount);
    $txn_purpose = mysqli_real_escape_string($connection, $txn_purpose);

    $insert_txn_query = "INSERT INTO trans(trans_user_id, trans_purpose, trans_icon_code, trans_category, trans_amount, trans_type, trans_date) VALUES($golspoh_session_user_id, '$txn_purpose', '$get_icon', '$get_category', '$txn_amount', '$get_type', '$current_date_time')";
    $insert_txn_result = mysqli_query($connection, $insert_txn_query);

    if(!$insert_txn_result){
        echo "<p class='error_msg'>Something went wrong. Try again</p>";
    }else{
        header('location: transaction.php');
    }
}
?>

<br><br><br><br><br><br>
</div>