<?php
if(isset($_GET['cus_id']) && isset($_GET['type'])){
    $get_cus_id = $_GET['cus_id'];
    $get_type = $_GET['type'];

    if(isset($_GET['equal'])){
        $get_equal_amount = $_GET['equal'];
    }
}else{
    header('location: credit.php');
}
?>
<!-- Page Heading Starts -->
<div class="page_heading">
    <a href="credit.php?page=customer&id=<?php echo $get_cus_id;?>">
        <div class="back_btn">
            <i class="bx bx-chevron-left"></i>
        </div>
    </a>
    <?php
if($get_type == 'lent'){
    echo "<div class='heading red'><i class='bx bxs-up-arrow-circle'></i> Add Lent</div>";
}else{
    echo "<div class='heading green'><i class='bx bxs-down-arrow-circle'></i> Add Borrowed</div>";
}
    ?>
</div>
<!-- Page Heading Ends -->

<div class="small_body_holder">
<?php
if(isset($_POST['submit'])){
    $credit_amount = $_POST['credit_amount'];
    $credit_date = date("d-m-Y", strtotime($_POST['credit_date']));
    $credit_time = date("H:i:s", strtotime($_POST['credit_time']));
    $credit_description = $_POST['credit_description'];

    $credit_amount = mysqli_real_escape_string($connection, $credit_amount);
    $credit_date = mysqli_real_escape_string($connection, $credit_date);
    $credit_time = mysqli_real_escape_string($connection, $credit_time);
    $credit_description = mysqli_real_escape_string($connection, $credit_description);

    if(empty($_FILES['credit_file']['name'])){
        $insert_credit_query = "INSERT INTO credit(credit_user_id, credit_cus_id, credit_amount, credit_date, credit_time, credit_type, credit_description) VALUES($golspoh_session_user_id, $get_cus_id, $credit_amount, '$credit_date', '$credit_time', '$get_type', '$credit_description')";
        $insert_credit_result = mysqli_query($connection, $insert_credit_query);
        if(!$insert_credit_result){
            echo "<p class='error_msg'>Something went wrong. Try again</p>";
        }else{
            if(isset($get_equal_amount)){
                header('location: credit.php?page=customer&id='.$get_cus_id.'&action=delete_cus');
            }else{
                header('location: credit.php?page=customer&id='.$get_cus_id);
            }
        }
    }else{
        $filename = $_FILES['credit_file']['name'];
        $mod_filename = $golspoh_session_user_id . date('YmdHis') .'-'. $filename;
        $extension = pathinfo($filename, PATHINFO_EXTENSION);
        $size = $_FILES['credit_file']['size'];

        if (!in_array($extension, ['png', 'jpg', 'jpeg', 'pdf'])) {
            echo "<font style='color: red;'>&#9888;&nbsp; Your file($filename) extension must be .pdf, .png, .jpg or .jpeg</font><br>";
        } elseif ($size > 5000000){
            echo "<font style='color: red;'>&#9888;&nbsp; File($filename) too large! Try uploading below 5MB.</font><br>";
        } elseif(strlen($credit_description) > 250) {
            echo "<font style='color: red;'>&#9888;&nbsp; Your Description must be below 250 charecters.</font><br>";
        }else{
            $insert_credit_query = "INSERT INTO credit(credit_user_id, credit_cus_id, credit_amount, credit_date, credit_time, credit_type, credit_file, credit_description) VALUES($golspoh_session_user_id, $get_cus_id, $credit_amount, '$credit_date', '$credit_time', '$get_type', '$mod_filename', '$credit_description')";
            $insert_credit_result = mysqli_query($connection, $insert_credit_query);
            if(!$insert_credit_result){
                echo "<p class='error_msg'>Something went wrong. Try again</p>";
            }else{
                move_uploaded_file($_FILES['credit_file']['tmp_name'],'../credit_files/'.$mod_filename);
                if(isset($get_equal_amount)){
                    header('location: credit.php?page=customer&id='.$get_cus_id.'&action=delete_cus');
                }else{
                    header('location: credit.php?page=customer&id='.$get_cus_id);
                }
            }
        }
    }
}
?>
<!-- Credit Info Starts -->
<section class="credit_info">
<?php
if(isset($get_equal_amount)){
    $custome_form_link = "credit.php?page=add_credit&cus_id=$get_cus_id&type=$get_type&equal=$get_equal_amount";
}else{
    $custome_form_link = "credit.php?page=add_credit&cus_id=$get_cus_id&type=$get_type";
}
?>
    <form action="<?php echo $custome_form_link; ?>" method="post" enctype="multipart/form-data">
        <div class="amount_container">
            <p>₹</p>
            <?php 
            if(isset($get_equal_amount)){
                echo "<input type='number' name='credit_amount' value='$get_equal_amount' placeholder='Amount' required />";
            }else{
                echo "<input type='number' name='credit_amount' placeholder='Amount' required />";
            }
            ?>
            <!-- <input type="number" name="credit_amount" placeholder="Amount" required /> -->
        </div>
        <div class="credit_payment_info">
            <div class="credit_info_holder">
                <p>Date:</p>
                <div class="credit_info_item">
                    <div class="credit_info_item_inside">
                        <input name="credit_date" required type="date" placeholder="dd-mm-yyyy" />
                    </div>
                </div>
            </div>
            <div class="credit_info_holder">
                <p>Time:</p>
                <div class="credit_info_item">
                    <div class="credit_info_item_inside">
                        <input name="credit_time" required type="time" />
                    </div>
                </div>
            </div>
            <div class="credit_info_holder">
                <p>Attach File:</p>
                <div class="credit_info_item">
                    <div class="credit_info_item_inside">
                        <input name="credit_file" type="file" class="input_file" />
                    </div>
                </div>
            </div>
            <div class="credit_description_container">
                <div class="credit_description_inside">
                    <textarea name="credit_description" placeholder="Description (Optional)"></textarea>
                </div>
            </div>
            <button type="submit" name="submit" class="btn center filled"><i class="bx bx-plus"></i> Submit</button>
        </div>
    </form>
</section>
<!-- Credit Info Ends -->



<br><br><br><br>
</div>