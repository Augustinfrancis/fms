<!-- Page Heading Starts -->
<div class="page_heading">
    <a href="credit.php">
        <div class="back_btn">
            <i class="bx bx-chevron-left"></i>
        </div>
    </a>
    <div class="heading"><i class="bx bxs-user-plus"></i> Add Customer</div>
</div>
<!-- Page Heading Ends -->
<div class="small_body_holder">
<!-- Form Section Starts -->
<div class="form_container">
    <form action="credit.php?page=add_customer" method="post">
    <div class="form_item">
        <div class="form_holder">
            <div class="icon">
                <i class="bx bxs-user"></i>
            </div>
            <div class="content">
                <input type="text" name="customer" required placeholder="Name" />
            </div>
        </div>
    </div>
    <div class="form_item">
        <div class="form_holder">
            <div class="icon">
                <i class="bx bxs-phone-call"></i>
            </div>
            <div class="content">
                <input type="number" name="number" placeholder="Phone (Optional)" />
            </div>
        </div>
    </div>
    <button name="submit" type="submit" class="btn center filled"><i class="bx bxs-user-plus"></i> Add Customer</button>
    </form>
</div>
<!-- Form Section Ends -->
<?php
if(isset($_POST['submit'])){
    $customer_name = strtolower($_POST['customer']);
    $customer_number = $_POST['number'];

    $customer_name = mysqli_real_escape_string($connection, $customer_name);
    $customer_number = mysqli_real_escape_string($connection, $customer_number);

    $select_all_customers_query = "SELECT * FROM credit_customers WHERE credit_customers_user_id = $golspoh_session_user_id AND credit_customers_name = '$customer_name'";
    $select_all_customers_result = mysqli_num_rows(mysqli_query($connection, $select_all_customers_query));
    
    if($select_all_customers_result < 1){
        if(empty($customer_number)){
            $insert_customer_query = "INSERT INTO credit_customers(credit_customers_user_id, credit_customers_name) VALUE($golspoh_session_user_id, '$customer_name')";
            $insert_customer_result = mysqli_query($connection, $insert_customer_query);
    
            if(!$insert_customer_result){
                echo "<p class='error_msg'>Oops! Somthing went wrong. Try again.</p>";
            }else{
                $select_redirect_user = mysqli_fetch_assoc(mysqli_query($connection, "SELECT credit_customers_id FROM credit_customers WHERE credit_customers_name = '$customer_name' AND credit_customers_user_id = $golspoh_session_user_id"));
                header('location: credit.php?page=customer&id='.$select_redirect_user['credit_customers_id']);
            }
        }else{
            if(strlen($customer_number) == 10){
                $insert_customer_query = "INSERT INTO credit_customers(credit_customers_user_id, credit_customers_name, credit_customers_phone) VALUE($golspoh_session_user_id, '$customer_name', $customer_number)";
                $insert_customer_result = mysqli_query($connection, $insert_customer_query);
    
                if(!$insert_customer_result){
                    echo "<p class='error_msg'>Oops! Somthing went wrong. Try again.</p>";
                }else{
                    $select_redirect_user = mysqli_fetch_assoc(mysqli_query($connection, "SELECT credit_customers_id FROM credit_customers WHERE credit_customers_name = '$customer_name' AND credit_customers_user_id = $golspoh_session_user_id"));
                    header('location: credit.php?page=customer&id='.$select_redirect_user['credit_customers_id']);
                }
            }else{
                echo "<p class='error_msg'>Mobile Number Must be 10 digits.</p>";
            }
        }
    }else{
        echo "<p class='error_msg'>This name is already added.</p>";
    }
    
}
?>
<br><br><br><br>
</div>