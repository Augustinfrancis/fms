<?php
if(isset($_GET['id'])){
    $get_cus_id = $_GET['id'];

    $user_total_lent = mysqli_fetch_array(mysqli_query($connection, "SELECT SUM(credit_amount) as user_lent_total FROM credit WHERE credit_user_id = $golspoh_session_user_id AND credit_type = 'lent' AND credit_cus_id = '$get_cus_id'"));
    $user_total_lent_sum = $user_total_lent['user_lent_total'];

    $user_total_debt = mysqli_fetch_array(mysqli_query($connection, "SELECT SUM(credit_amount) as user_debt_total FROM credit WHERE credit_user_id = $golspoh_session_user_id AND credit_type = 'debt' AND credit_cus_id = '$get_cus_id'"));
    $user_total_debt_sum = $user_total_debt['user_debt_total'];

    $total_user_total = $user_total_lent_sum - $user_total_debt_sum;
    $convert_total_user_total = abs($total_user_total);
}else{
    header('location: credit.php');
}

if(isset($_GET['action'])){
    if($_GET['action'] == 'delete_credits'){
        $delete_all_credits_query = "DELETE FROM credit WHERE credit_user_id = $golspoh_session_user_id AND credit_cus_id = $get_cus_id";
        $delete_all_credits_result = mysqli_query($connection, $delete_all_credits_query);
        header('location: credit.php?page=customer&id='.$get_cus_id);
    }elseif($_GET['action'] == 'delete_cus'){
        if($total_user_total == 0){
            $delete_all_credits_query = "DELETE FROM credit WHERE credit_user_id = $golspoh_session_user_id AND credit_cus_id = $get_cus_id";
            $delete_all_credits_result = mysqli_query($connection, $delete_all_credits_query);
            
            $delete_customer_query = "DELETE FROM credit_customers WHERE credit_customers_id = $get_cus_id AND credit_customers_user_id = $golspoh_session_user_id";
            $delete_customer_result = mysqli_query($connection, $delete_customer_query);

            header('location: credit.php');
        }
    }
}

$select_customer_query = "SELECT * FROM credit_customers WHERE credit_customers_user_id = $golspoh_session_user_id AND credit_customers_id = $get_cus_id";
$select_customer_result = mysqli_fetch_assoc(mysqli_query($connection, $select_customer_query));

?>
<!-- Page Heading Starts -->
<div class="page_heading">
    <a href="credit.php">
        <div class="back_btn">
            <i class="bx bx-chevron-left"></i>
        </div>
    </a>
    <div class="heading"><i class="bx bxs-user-circle"></i> <?php echo $select_customer_result['credit_customers_name']; ?></div>
    <div class="filter_btn" onclick="openOptionsModel()"><i class="bx bx-dots-vertical-rounded"></i></div>
</div>
<!-- <div class="page_heading_spacefill"></div> -->
<!-- Page Heading Ends -->

<div class="credit_customer_holder">
<section class="credits_txn_container">
    <?php
$select_all_credits_query = "SELECT * FROM credit WHERE credit_user_id = $golspoh_session_user_id AND credit_cus_id = $get_cus_id";
$select_all_credits_result = mysqli_query($connection, $select_all_credits_query);
while($row = mysqli_fetch_assoc($select_all_credits_result)){
    $credit_id = $row['credit_id'];
    $credit_amount = $row['credit_amount'];
    $credit_date = $row['credit_date'];
    $credit_time = date("h:m A", strtotime($row['credit_time']));
    $credit_type = $row['credit_type'];

    if($credit_type == 'debt'){
        ?>
            <a href="credit.php?page=credit_info&cus_id=<?php echo $get_cus_id; ?>&credit_id=<?php echo $credit_id; ?>">
                <div class="credit_txn_item">
                    <div class="credit_thx_holder green">
                        <h4><?php echo $user_currency.$credit_amount; ?> <i class="bx bxs-down-arrow-circle"></i></h4>
                        <p><?php echo $credit_date . ' - ' . $credit_time; ?></p>
                    </div>
                </div>
            </a>
        <?php
    }elseif($credit_type == 'lent'){
        ?>
            <a href="credit.php?page=credit_info&cus_id=<?php echo $get_cus_id; ?>&credit_id=<?php echo $credit_id; ?>">
                <div class="credit_txn_item right">
                    <div class="credit_thx_holder red">
                        <h4><?php echo $user_currency.$credit_amount; ?> <i class="bx bxs-up-arrow-circle"></i></h4>
                        <p><?php echo $credit_date . ' - ' . $credit_time; ?></p>
                    </div>
                </div>
            </a>
        <?php
    }
}
    ?>
    
</section>
</div>
<div class="balance_container">
    <div class="balance">
        <!-- This may change: Due / Collection -->
        <?php
if($total_user_total < 0){
    echo "<p>Balance Due:</p><div class='amount_container red'>$user_currency$total_user_total <i class='bx bxs-up-arrow-circle'></i></div>";
}elseif($total_user_total > 0){
    echo "<p>Balance Collection:</p><div class='amount_container green'>$user_currency$total_user_total <i class='bx bxs-down-arrow-circle'></i></div>";
}else{
    echo "<p>No Due</p><div class='amount_container'>$user_currency$total_user_total</div>";
}
        ?>
    </div>

    <div class="credit_btn_container">
        <a href="credit.php?page=add_credit&cus_id=<?php echo $get_cus_id; ?>&type=debt">
            <div class="credit_btn green"><i class="bx bxs-down-arrow-circle"></i>Received</div>
        </a>
        <a href="credit.php?page=add_credit&cus_id=<?php echo $get_cus_id; ?>&type=lent">
            <div class="credit_btn red"><i class="bx bxs-up-arrow-circle"></i>Given</div>
        </a>
    </div>
</div>
<!-- Credit Options Model -->
<div class="credit_options_model" id="creditOptionsModel">
    <div class="credit_options_container">
        <div class="credit_options_container_inside">
            <?php
if($select_customer_result['credit_customers_phone'] > 0){
?>
            <a href="tel:<?php echo $select_customer_result['credit_customers_phone']; ?>">
                <button class="btn center filled"><i class="bx bxs-phone-call"></i> Call</button>
            </a>
<?php
}
            ?>
            <?php
if($total_user_total == 0){
?>
            <a href="credit.php?page=customer&id=<?php echo $get_cus_id ?>&action=delete_cus">
                <button class="btn center filled"><i class="bx bxs-trash"></i> Delete</button>
            </a>
<?php
}else{
?>
            <button class="btn center filled" onclick="openDeleteDialog()"><i class="bx bxs-trash"></i> Delete</button>
<?php
}
            ?>
            <?php
if($select_customer_result['credit_customers_phone'] > 0){
    if($total_user_total > 0){
        ?>
            <a href="whatsapp://send?text=Hi%20I'm%20<?php echo $user_name; ?>.%20The%20due%20that%20is%20need%20to%20be%20settled%20to%20you%20of%20<?php echo $user_currency.$convert_total_user_total; ?>%20will%20be%20settled%20ASAP.">
                <button class="btn center filled"><i class='bx bxl-whatsapp' ></i> Remind</button>
            </a>
        <?php
    }elseif($total_user_total < 0){
        ?>
            <a href="whatsapp://send?text=Hi%20I'm%20<?php echo $user_name; ?>.%20You%20have%20to%20settle%20your%20due%20of%20<?php echo $user_currency.$convert_total_user_total; ?>.%20Please%20settle%20it%20ASAP.">
                <button class="btn center filled"><i class='bx bxl-whatsapp' ></i> Remind</button>
            </a>
        <?php
    }
}
            ?>
            <a href="credit.php?page=customer&id=<?php echo $get_cus_id ?>&action=delete_credits">
                <button class="btn center filled"><i class='bx bxs-folder-minus'></i> Clear All</button>
            </a>
        </div>
    </div>
</div>

<!-- Popup Model -->
<div class="delete_model" id="deleteModel">
    <div class="delete_container">
        <div class="delete_container_inside">
            <p>You must equal the Balance</p>
            <div class="category_container">
                <?php
                
if($total_user_total < 0){
?>
                <a href="credit.php?page=add_credit&cus_id=<?php echo $get_cus_id; ?>&type=lent&equal=<?php echo $convert_total_user_total; ?>">
                    <div class="category_item red"><i class='bx bxs-up-arrow-circle'></i>Give</div>
                </a>
                <div class="category_item green" onclick="closeDeleteDialog()"><i class="bx bx-block"></i> Cancel</div>
<?php
}else{
?>
                <a href="credit.php?page=add_credit&cus_id=<?php echo $get_cus_id; ?>&type=debt&equal=<?php echo $convert_total_user_total; ?>">
                    <div class="category_item green"><i class='bx bxs-down-arrow-circle'></i>Get</div>
                </a>
                <div class="category_item red" onclick="closeDeleteDialog()"><i class="bx bx-block"></i> Cancel</div>
<?php
}
                ?>
            </div>
        </div>
    </div>
</div>