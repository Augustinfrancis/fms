<?php
if(isset($_GET['cus_id']) && isset($_GET['credit_id'])){
    $get_cus_id = $_GET['cus_id'];
    $get_credit_id = $_GET['credit_id'];

    $select_credit_customer_query = "SELECT * FROM credit_customers WHERE credit_customers_user_id = $golspoh_session_user_id AND credit_customers_id = $get_cus_id";
    $select_credit_customer_result = mysqli_fetch_assoc(mysqli_query($connection, $select_credit_customer_query));

    $select_credit_query = "SELECT * FROM credit WHERE credit_user_id = $golspoh_session_user_id AND credit_id = $get_credit_id AND credit_cus_id = $get_cus_id";
    $select_credit_result = mysqli_query($connection, $select_credit_query);
    while($row = mysqli_fetch_assoc($select_credit_result)){
        $credit_amount = $row['credit_amount'];
        $credit_date = $row['credit_date'];
        $credit_time = $row['credit_time'];
        $credit_type = $row['credit_type'];
        $credit_file = $row['credit_file'];
        $credit_description = $row['credit_description'];
    }
}else{
    header('location: customer.php');
}
if(isset($_GET['action'])){
    if($_GET['action'] == 'file_delete'){
        $update_file_query = "UPDATE credit SET credit_file = '' WHERE credit_id = $get_credit_id AND credit_user_id = $golspoh_session_user_id AND credit_cus_id = $get_cus_id";
        $update_file_result = mysqli_query($connection, $update_file_query);
        header('location: credit.php?page=credit_info&cus_id='.$get_cus_id.'&credit_id='.$get_credit_id);
    }elseif($_GET['action'] == 'credit_delete'){
        $delete_credit_query = "DELETE FROM credit WHERE credit_id = $get_credit_id AND credit_user_id = $golspoh_session_user_id AND credit_cus_id = $get_cus_id";
        $delete_credit_result = mysqli_query($connection, $delete_credit_query);
        header('location: credit.php?page=customer&id='.$get_cus_id);
    }
}
?>

<!-- Page Heading Starts -->
<div class="page_heading">
    <a href="credit.php?page=customer&id=<?php echo $get_cus_id; ?>">
        <div class="back_btn">
            <i class="bx bx-chevron-left"></i>
        </div>
    </a>
    <div class="heading"><i class="bx bxs-user-circle"></i> <?php echo $select_credit_customer_result['credit_customers_name']; ?></div>
</div>
<!-- <div class="page_heading_spacefill"></div> -->
<!-- Page Heading Ends -->

<div class="small_body_holder">
<?php
if(isset($_POST['submit'])){
    $credit_amount = $_POST['credit_amount'];
    $credit_date = date("d-m-Y", strtotime($_POST['credit_date']));
    $credit_time = date("H:i:s", strtotime($_POST['credit_time']));
    $credit_description = $_POST['credit_description'];

    $credit_amount = mysqli_real_escape_string($connection, $credit_amount);
    $credit_date = mysqli_real_escape_string($connection, $credit_date);
    $credit_time = mysqli_real_escape_string($connection, $credit_time);
    $credit_description = mysqli_real_escape_string($connection, $credit_description);

    if(empty($_FILES['credit_file']['name'])){
        $update_credit_query = "UPDATE credit SET credit_amount = $credit_amount, credit_date = '$credit_date', credit_time = '$credit_time', credit_description = '$credit_description' WHERE credit_id = $get_credit_id AND credit_user_id = $golspoh_session_user_id AND credit_cus_id = $get_cus_id";
        $update_credit_result = mysqli_query($connection, $update_credit_query);
        if(!$update_credit_result){
            echo "<p class='error_msg'>Something went wrong. Try again</p>";
        }else{
            header('location: credit.php?page=credit_info&cus_id='.$get_cus_id.'&credit_id='.$get_credit_id);
        }
    }else{
        $filename = $_FILES['credit_file']['name'];
        $mod_filename = $golspoh_session_user_id . date('YmdHis') .'-'. $filename;
        $extension = pathinfo($filename, PATHINFO_EXTENSION);
        $size = $_FILES['credit_file']['size'];

        if (!in_array($extension, ['png', 'jpg', 'jpeg', 'pdf'])) {
            echo "<font style='color: red;'>&#9888;&nbsp; Your file($filename) extension must be .pdf, .png, .jpg or .jpeg</font><br>";
        } elseif ($size > 5000000){
            echo "<font style='color: red;'>&#9888;&nbsp; File($filename) too large! Try uploading below 5MB.</font><br>";
        } elseif(strlen($credit_description) > 250) {
            echo "<font style='color: red;'>&#9888;&nbsp; Your Description must be below 250 charecters.</font><br>";
        }else{
            $update_credit_query = "UPDATE credit SET credit_amount = $credit_amount, credit_date = '$credit_date', credit_time = '$credit_time', credit_file = '$mod_filename', credit_description = '$credit_description' WHERE credit_id = $get_credit_id AND credit_user_id = $golspoh_session_user_id AND credit_cus_id = $get_cus_id";
            $update_credit_result = mysqli_query($connection, $update_credit_query);
            if(!$update_credit_result){
                echo "<p class='error_msg'>Something went wrong. Try again</p>";
            }else{
                move_uploaded_file($_FILES['credit_file']['tmp_name'],'../credit_files/'.$mod_filename);
                header('location: credit.php?page=credit_info&cus_id='.$get_cus_id.'&credit_id='.$get_credit_id);
            }
        }
    }
}
?>
<!-- Credit Info Starts -->
<section class="credit_info">
<form action="credit.php?page=credit_info&cus_id=<?php echo $get_cus_id; ?>&credit_id=<?php echo $get_credit_id; ?>" method="post" enctype="multipart/form-data">
    <div class="amount_container">
        <p>₹</p>
        <input type="number" name="credit_amount" required value="<?php echo $credit_amount; ?>" placeholder="Amount" />
    </div>
    <div class="credit_payment_info">
        <div class="credit_info_holder">
            <p>Date:</p>
            <div class="credit_info_item">
                <div class="credit_info_item_inside">
                    <input name="credit_date" required type="date" placeholder="dd-mm-yyyy" value="<?php echo date("Y-m-d", strtotime($credit_date)); ?>" />
                </div>
            </div>
        </div>
        <div class="credit_info_holder">
            <p>Time:</p>
            <div class="credit_info_item">
                <div class="credit_info_item_inside">
                    <input name="credit_time" required type="time" value="<?php echo $credit_time; ?>" />
                </div>
            </div>
        </div>
        <div class="credit_info_holder">
            <p>Attach File:</p>
            <div class="credit_info_item">
                <div class="credit_info_item_inside" style="justify-content:space-evenly;">
                    <?php
if(empty($credit_file)){
    echo "<input name='credit_file' type='file' class='input_file' />";
}else{
    echo "<div class='credit_delete_btn' style='background: #00caff;' onclick='openPreviewModel()'><i class='bx bxs-file'></i></div>";
    echo "<a href='credit.php?page=credit_info&cus_id=$get_cus_id&credit_id=$get_credit_id&action=file_delete'><div class='credit_delete_btn'><i class='bx bxs-trash'></i></div></a>";
    // .
}
                    ?>
                    <!-- <input type="file" class="input_file" /> -->
                </div>
            </div>
        </div>
        <div class="credit_description_container">
            <div class="credit_description_inside">
                <textarea name="credit_description" placeholder="Description (Optional)"><?php echo $credit_description; ?></textarea>
            </div>
        </div>
        <button type="submit" name="submit" class="btn center filled"><i class="bx bxs-user-plus"></i> Save Changes</button>
        <p class="delete_para" onclick="openDeleteDialog()"><i class="bx bxs-trash"></i> Delete Transaction</p>
    </div>
</section>
<!-- Credit Info Ends -->
<br><br><br><br>
</div>

<!-- Popup Model -->
<div class="delete_model" id="deleteModel">
    <div class="delete_container">
        <div class="delete_container_inside">
            <p>Are you sure?</p>
            <div class="category_container">
                <a href="credit.php?page=credit_info&cus_id=<?php echo $get_cus_id; ?>&credit_id=<?php echo $get_credit_id; ?>&action=credit_delete">
                    <div class="category_item red"><i class="bx bxs-trash"></i> Delete</div>
                </a>
                <div class="category_item green" onclick="closeDeleteDialog()"><i class="bx bx-block"></i> Cancel</div>
            </div>
        </div>
    </div>
</div>

<div class="preview_model" id="previewModel">
    <div class="close_btn_popup" onclick="closePreviewModel()">
        <i class='bx bx-x'></i>
    </div>
    <div class="preview_container">
        <div class="preview_container_inside">
            <?php
if(isset($credit_file)){
    $extension = pathinfo($credit_file, PATHINFO_EXTENSION);

    if($extension == 'pdf'){
        ?>
            <a href="../credit_files/<?php echo $credit_file; ?>" download><button type="button" class="btn filled center"><i class='bx bxs-download'></i> Download PDF</button></a>
        <?php
    }else{
        ?>
            <img class="preview_img" src="../credit_files/<?php echo $credit_file; ?>">
        <?php
    }
}
            ?>
        </div>
    </div>
</div>