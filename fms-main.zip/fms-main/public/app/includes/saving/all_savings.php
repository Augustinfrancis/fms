<!-- Page Heading Starts -->
<div class="page_heading">
    <a href="saving.php">
        <div class="back_btn">
            <i class="bx bx-chevron-left"></i>
        </div>
    </a>
    <div class="heading">All Savings</div>
    <div class="filter_btn" onclick="openFilter()"><i class="bx bx-filter-alt"></i></div>
</div>
<!-- Page Heading Ends -->

<div class="small_body_holder">
<!-- List Starts -->
<section class="txn_container">
    <div class="search_container">
        <div class="search_holder">
            <div class="field">
                <input type="text" id="searchTxn" onkeyup="searchTransaction()" placeholder="Search Transaction" />
            </div>
            <div class="icon">
                <i class="bx bx-search-alt-2"></i>
            </div>
        </div>
    </div>
    <div class="txn_content" id="txnContainer">
    <?php
if(isset($_GET['delete_saving'])){
    $delete_saving_id = $_GET['delete_saving'];

    $delete_saving_query = "DELETE FROM savings WHERE savings_id = $delete_saving_id AND savings_user_id = $golspoh_session_user_id";
    $delete_saving_result = mysqli_query($connection, $delete_saving_query);

    header('location: saving.php?page=all_savings');
}
$select_recent_transaction_query = "SELECT * FROM savings WHERE savings_user_id = $golspoh_session_user_id";
$select_recent_transaction_result = mysqli_query($connection, $select_recent_transaction_query);
while($row = mysqli_fetch_assoc($select_recent_transaction_result)){
    $savings_id = $row['savings_id'];
    $savings_amount = $row['savings_amount'];
    $savings_title = $row['savings_title'];
    $savings_category = $row['savings_category'];
    $savings_date = strtotime($row['savings_date']);

    if(isset($_GET['filterfrom']) && isset($_GET['filterto'])){
        $startdate = strtotime($_GET['filterfrom']);
        $enddate = strtotime($_GET['filterto']);

        if($startdate <= $savings_date && $savings_date <= $enddate) {
            ?>
        <div class="txn_item">
            <div class="txn_inside">
                <div class="txn_icon">
                    <i class='bx bxs-wallet'></i>
                </div>
                <div class="txn_text">
                    <h4><?php echo $savings_title; ?></h4>
                    <span><?php echo $savings_category; ?></span>
                </div>
                <div class="txn_amount">
                    <p class='green'><?php echo $user_currency.$savings_amount; ?></p>
                    <span><?php echo date("d-m-Y", $savings_date); ?></span>
                </div>
            </div>
            <a href="saving.php?page=all_savings&delete_saving=<?php echo $savings_id; ?>"><div class="txn_delete_btn">
                <i class='bx bxs-trash'></i>
            </div></a>
        </div>
            <?php
        }
    }else{    
        ?>
        <div class="txn_item">
            <div class="txn_inside">
                <div class="txn_icon">
                    <i class='bx bxs-wallet'></i>
                </div>
                <div class="txn_text">
                    <h4><?php echo $savings_title; ?></h4>
                    <span><?php echo $savings_category; ?></span>
                </div>
                <div class="txn_amount">
                    <p class='green'><?php echo $user_currency.$savings_amount; ?></p>
                    <span><?php echo date("d-m-Y", $savings_date); ?></span>
                </div>
            </div>
            <a href="saving.php?page=all_savings&delete_saving=<?php echo $savings_id; ?>"><div class="txn_delete_btn">
                <i class='bx bxs-trash'></i>
            </div></a>
        </div>
        <?php
}
}
        ?>
    </div>
</section>
<br><br><br><br>
<!-- List End -->
</div>
