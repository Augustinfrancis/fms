<?php

?>
<!-- Page Heading Starts -->
<div class="page_heading">
    <a href="saving.php">
        <div class="back_btn">
            <i class="bx bx-chevron-left"></i>
        </div>
    </a>
    <div class='heading green'>Add Custom Saving</div>
</div>
<!-- Page Heading Ends -->

<div class="small_body_holder">
<?php
if(isset($_POST['submit'])){
    $credit_amount = $_POST['credit_amount'];
    $credit_date = date("d-m-Y", strtotime($_POST['credit_date']));

    $credit_amount = mysqli_real_escape_string($connection, $credit_amount);
    $credit_date = mysqli_real_escape_string($connection, $credit_date);

    $insert_credit_query = "INSERT INTO savings_history(savings_history_user_id, savings_history_amount, savings_history_title, savings_history_category, savings_history_date) VALUES($golspoh_session_user_id, $credit_amount, 'Custom', 'Custom', '$credit_date')";
    $insert_credit_result = mysqli_query($connection, $insert_credit_query);
    if(!$insert_credit_result){
        echo "<p class='error_msg'>Something went wrong. Try again</p>";
    }else{
        header('location: saving.php');
    }
}
?>
<!-- Credit Info Starts -->
<section class="credit_info">
    <form action="saving.php?page=add_custom" method="post">
        <div class="amount_container">
            <p>₹</p>
            <input type="number" name="credit_amount" placeholder="Amount" required />
        </div>
        <div class="credit_payment_info">
            <div class="credit_info_holder">
                <p>Date:</p>
                <div class="credit_info_item">
                    <div class="credit_info_item_inside">
                        <input name="credit_date" required type="date" placeholder="dd-mm-yyyy" />
                    </div>
                </div>
            </div>
            <button type="submit" name="submit" class="btn center filled"><i class="bx bx-plus"></i> Submit</button>
        </div>
    </form>
</section>
<!-- Credit Info Ends -->
<br><br><br><br>
</div>