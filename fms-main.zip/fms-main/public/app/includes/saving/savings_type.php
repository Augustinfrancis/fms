<!-- Page Heading Starts -->
<div class="page_heading">
    <a href="saving.php">
        <div class="back_btn">
            <i class="bx bx-chevron-left"></i>
        </div>
    </a>
    <div class='heading green'>Add Savings</div>
</div>
<!-- Page Heading Ends -->
<div class="small_body_holder">
<!-- Form Section Starts -->
<section class="amount_section">
    <?php

    if(isset($_POST['submit'])){
        if(empty($_POST['goal_type'])){
            echo "<p class='error_msg'>Please choose any one goal type.</p>";
        }elseif(empty($_POST['goal_name'])){
            echo "<p class='error_msg'>Please give a name for your saving goal.</p>";
        }else{
            $goal_name = $_POST['goal_name'];
            $goal_type = $_POST['goal_type'];
            header('location: saving.php?page=savings_form&goalname=' . $goal_name . '&goaltype=' . $goal_type);
        }
    }
    ?>
    <form action="saving.php?page=savings_type" method="post">
        <h4>Enter Goal Name:</h4>
        <div class="search_container">
            <div class="search_holder">
                <div class="field">
                    <input type="text" name="goal_name" placeholder="Eg: Bike Goal" required />
                </div>
            </div>
        </div>
        <h4>Choose Goal Type:</h4>
        <div class="goal_type_container">
            <input type="radio" value="mode1" name="goal_type" id="mode1">
            <label for="mode1">
                <div class="options_holder">
                    <h5>52-week challernge</h5>
                    <i class='bx bxs-info-circle' onclick="openinfoModel('52-week challenge', 'Using the 52-week money challenge, you should deposit an increasing amount of money each week for one year.<br><br>You’ll save <?php echo $user_currency; ?>10 the first week, <?php echo $user_currency; ?>20 the second week, <?php echo $user_currency; ?>30 the third week, and so on until you put away <?php echo $user_currency; ?>520 in week 52.<br><br>If you stick to this example throughout the entire year, you’ll save a total of <?php echo $user_currency; ?>13,780.')"></i>
                </div>
            </label>
            <input type="radio" value="mode2" name="goal_type" id="mode2">
            <label for="mode2">
                <div class="options_holder">
                    <h5>Target Amount Challenge</h5>
                    <i class='bx bxs-info-circle' onclick="openinfoModel('Target Amount Challenge', 'Using the Target Amount Challenge you will set the target amount and we will tell you how much you should save daily, weekly, monthly or yearly.')"></i>
                </div>
            </label>
            <input type="radio" value="mode3" name="goal_type" id="mode3">
            <label for="mode3">
                <div class="options_holder">
                    <h5>Target Date Challenge</h5>
                    <i class='bx bxs-info-circle' onclick="openinfoModel('Target Amount Challenge', 'Using the Target Date Challenge you will set the starting date and end date and we will tell you how much you should save daily, weekly, monthly or yearly.')"></i>
                </div>
            </label>
        </div>
        <button type="submit" name="submit" class="btn stroke center"><i class="bx bx-plus-medical"></i> Create Goal</button>
    </form>
</section>
<!-- Form Section Ends -->

<br><br><br><br><br><br>
</div>