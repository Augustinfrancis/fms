<?php

if(isset($_GET['goalname']) && isset($_GET['goaltype'])){
    $get_goal_name = $_GET['goalname'];
    $get_goal_type = $_GET['goaltype'];
}else{
    header("location: saving.php");
}

?>
<!-- Page Heading Starts -->
<div class="page_heading">
    <a href="saving.php?page=savings_type">
        <div class="back_btn">
            <i class="bx bx-chevron-left"></i>
        </div>
    </a>
    <div class='heading'>Add Challenge</div>
</div>
<!-- Page Heading Ends -->
<div class="small_body_holder">

<!-- Form Section Starts -->
<?php
switch ($get_goal_type) {
    case 'mode1':
        $mod_goal_type = "52-week challenge";

        if(isset($_POST['submit'])){
            $interval_amount = $_POST['goal_interval_amount'];
            $goal_start_date = $_POST['goal_start_date'];
            $total_amount = $interval_amount * 52;
            $goal_end_date = date('d-m-Y', strtotime($goal_start_date .'+52 weeks'));

            $insert_mode1_query = "INSERT INTO savings(savings_user_id, savings_amount, savings_amount_interval, savings_title, savings_category, savings_date, savings_start_date, savings_end_date) VALUES($golspoh_session_user_id, $total_amount, $interval_amount, '$get_goal_name', '$mod_goal_type', '$current_date_time', '$goal_start_date', '$goal_end_date')";
            $insert_mode1_result = mysqli_query($connection, $insert_mode1_query);
            if(!$insert_mode1_result){
                echo "Query Failed";
            }else{
                header('location:savings.php');
            }
        }
        ?>
<section class="amount_section">
    <form action="saving.php?page=savings_form&goalname=<?php echo $get_goal_name; ?>&goaltype=<?php echo $get_goal_type; ?>" method="post">
        <h4>Challenge Type:</h4>
        <div class="search_container">
            <div class="search_holder">
                <select class="field" disabled>
                    <option value="mode1" selected>52-week Challenge</option>
                </select>
            </div>
        </div>
        <h4>Interval Amount</h4>
        <div class="search_container">
            <div class="search_holder">
                <div class="field">
                    <input type="number" id="goal_interval_amount" onkeyup="calcMode1()" name="goal_interval_amount" placeholder="How much are you saving weekly?" required />
                </div>
            </div>
        </div>
        <h4>Interval Unit:</h4>
        <div class="search_container">
            <div class="search_holder">
                <select class="field" disabled>
                    <option value="weekly" selected>Weekly</option>
                </select>
            </div>
        </div>
        <h4>Start Date:</h4>
        <div class="search_container">
            <div class="search_holder">
                <div class="field">
                    <input type="date" id="mode1StartDate" value="<?php echo date('Y-m-d'); ?>" name="goal_start_date" required />
                </div>
            </div>
        </div>
        <h4>Goal Amount:</h4>
        <div class="search_container">
            <div class="search_holder">
                <div class="field">
                    <input type="number" id="total_goal_amount" placeholder="Complete Input to calc" disabled required />
                </div>
            </div>
        </div>
        
        <h4>End Date:</h4>
        <div class="search_container">
            <div class="search_holder">
                <div class="field">
                    <input type="date" id="goal_end_date" disabled required />
                </div>
            </div>
        </div>
        <p onclick="calcMode1()"><b>Click to calc</b></p>

        <button type="submit" name="submit" class="btn stroke center"><i class="bx bx-plus-medical"></i> Create Goal</button>
    </form>
</section>
        <?php
        break;
    case 'mode2':
        $mod_goal_type = "Target Amount Challenge";

        if(isset($_POST['submit'])){
            $goal_start_date = strtotime($_POST['goal_start_date']);
            $goal_end_date = strtotime($_POST['goal_end_date']);
            
            $mod_goal_start_date = date('d-m-Y', strtotime($_POST['goal_start_date']));
            $mod_goal_end_date = date('d-m-Y', strtotime($_POST['goal_end_date']));
            
            $interval_unit = $_POST['interval_unit'];
            $total_goal_amount = $_POST['total_goal_amount'];

            $differece_time = $goal_end_date - $goal_start_date;
            

            if($goal_end_date >= $goal_start_date){
                if($interval_unit == "daily"){
                    $differece_value = 1 + $differece_time / (60 * 60 * 24);
                }elseif($interval_unit == "weekly"){
                    $differece_value = floor($differece_time / (60 * 60 * 24 * 7)) + 1;
                }elseif($interval_unit == "monthly"){
                    $year1 = date('Y', $goal_start_date);
                    $year2 = date('Y', $goal_end_date);

                    $month1 = date('m', $goal_start_date);
                    $month2 = date('m', $goal_end_date);

                    $differece_value = (($year2 - $year1) * 12) + ($month2 - $month1);
                }elseif($interval_unit == "yearly"){
                    $year1 = date('Y', $goal_start_date);
                    $year2 = date('Y', $goal_end_date);

                    $differece_value = $year2 - $year1 + 1;
                }

                $interval_amount_save = ceil($total_goal_amount / $differece_value);

                $insert_saving_query = "INSERT INTO savings(savings_user_id, savings_amount, savings_amount_interval, savings_interval_unit, savings_title, savings_category, savings_date, savings_start_date, savings_end_date) VALUES($golspoh_session_user_id, $total_goal_amount, $interval_amount_save, '$interval_unit', '$get_goal_name', '$mod_goal_type', '$current_date_time', '$mod_goal_start_date', '$mod_goal_end_date')";
                $insert_saving_result = mysqli_query($connection, $insert_saving_query);

                if(!$insert_saving_result){
                    echo "<p class='error_msg'>Something went wrong. Please try again.</p>";
                }else{
                    header('location: saving.php');
                }
            }else{
                echo "<p class='error_msg'>End Date must be later than Start date.</p>";
            }
        }
        ?>
<section class="amount_section">
    <form action="saving.php?page=savings_form&goalname=<?php echo $get_goal_name; ?>&goaltype=<?php echo $get_goal_type; ?>" method="post">
        <h4>Challenge Type:</h4>
        <div class="search_container">
            <div class="search_holder">
                <select class="field" disabled>
                    <option value="mode2" selected>Target Amount Challenge</option>
                </select>
            </div>
        </div>
        <h4>Start Date:</h4>
        <div class="search_container">
            <div class="search_holder">
                <div class="field">
                    <input type="date" id="start_date" value="<?php echo date('Y-m-d'); ?>" name="goal_start_date" required />
                </div>
            </div>
        </div>
        <h4>End Date:</h4>
        <div class="search_container">
            <div class="search_holder">
                <div class="field">
                    <input type="date" id="end_date" value="<?php echo date('Y-m-d'); ?>" name="goal_end_date" required />
                </div>
            </div>
        </div>
        <h4>How frequently will you save?</h4>
        <div class="search_container">
            <div class="search_holder">
                <select class="field" onchange="calcMode2()" id="interval_unit" name="interval_unit" required>
                    <option value="daily">Daily</option>
                    <option value="weekly">Weekly(7 days)</option>
                    <option value="monthly">Monthly(30 days)</option>
                    <option value="yearly">Yearly(365 days)</option>
                </select>
            </div>
        </div>
        <h4>Goal Amount:</h4>
        <div class="search_container">
            <div class="search_holder">
                <div class="field">
                    <input type="number" onkeyup="calcMode2()" id="total_goal_amount" name="total_goal_amount" placeholder="How much you want to save?" required />
                </div>
            </div>
        </div>
        <h4>You should save - </h4>
        <div class="search_container">
            <div class="search_holder">
                <div class="field">
                    <input type="text" id="goal_interval_amount" name="goal_interval_amount" placeholder="You should save" disabled required />
                </div>
            </div>
        </div>
        <p onclick="calcMode2()"><b>Click to calc</b></p>
        <button type="submit" name="submit" class="btn stroke center"><i class="bx bx-plus-medical"></i> Create Goal</button>
    </form>
</section>
        <?php
        break;
    case 'mode3':
        $mod_goal_type = "Target Date Challenge";

        if(isset($_POST['submit'])){
            $goal_start_date = strtotime($_POST['goal_start_date']);
            $goal_end_date = strtotime($_POST['goal_end_date']);
            
            $mod_goal_start_date = date('d-m-Y', strtotime($_POST['goal_start_date']));
            $mod_goal_end_date = date('d-m-Y', strtotime($_POST['goal_end_date']));
            
            $interval_unit = $_POST['interval_unit'];
            $goal_interval_amount = $_POST['goal_interval_amount'];

            $differece_time = $goal_end_date - $goal_start_date;
            

            if($goal_end_date >= $goal_start_date){
                if($interval_unit == "daily"){
                    $differece_value = 1 + $differece_time / (60 * 60 * 24);
                }elseif($interval_unit == "weekly"){
                    $differece_value = floor($differece_time / (60 * 60 * 24 * 7)) + 1;
                }elseif($interval_unit == "monthly"){
                    $year1 = date('Y', $goal_start_date);
                    $year2 = date('Y', $goal_end_date);

                    $month1 = date('m', $goal_start_date);
                    $month2 = date('m', $goal_end_date);

                    $differece_value = (($year2 - $year1) * 12) + ($month2 - $month1);
                }elseif($interval_unit == "yearly"){
                    $year1 = date('Y', $goal_start_date);
                    $year2 = date('Y', $goal_end_date);

                    $differece_value = $year2 - $year1 + 1;
                }

                $total_amount_save = ceil($differece_value * $goal_interval_amount);

                $insert_saving_query = "INSERT INTO savings(savings_user_id, savings_amount, savings_amount_interval, savings_interval_unit, savings_title, savings_category, savings_date, savings_start_date, savings_end_date) VALUES($golspoh_session_user_id, $total_amount_save, $goal_interval_amount, '$interval_unit', '$get_goal_name', '$mod_goal_type', '$current_date_time', '$mod_goal_start_date', '$mod_goal_end_date')";
                $insert_saving_result = mysqli_query($connection, $insert_saving_query);

                if(!$insert_saving_result){
                    echo "<p class='error_msg'>Something went wrong. Please try again.</p>";
                }else{
                    header('location: saving.php');
                }
            }else{
                echo "<p class='error_msg'>End Date must be later than Start date.</p>";
            }
        }
        ?>
<section class="amount_section">
    <form action="saving.php?page=savings_form&goalname=<?php echo $get_goal_name; ?>&goaltype=<?php echo $get_goal_type; ?>" method="post">
        <h4>Challenge Type:</h4>
        <div class="search_container">
            <div class="search_holder">
                <select class="field" disabled>
                    <option value="mode2" selected>Target Date Challenge</option>
                </select>
            </div>
        </div>
        <h4>Start Date:</h4>
        <div class="search_container">
            <div class="search_holder">
                <div class="field">
                    <input type="date" id="start_date" value="<?php echo date('Y-m-d'); ?>" name="goal_start_date" required />
                </div>
            </div>
        </div>
        <h4>End Date:</h4>
        <div class="search_container">
            <div class="search_holder">
                <div class="field">
                    <input type="date" id="end_date" value="<?php echo date('Y-m-d'); ?>" name="goal_end_date" required />
                </div>
            </div>
        </div>
        <h4>How much you will save?</h4>
        <div class="search_container">
            <div class="search_holder">
                <div class="field">
                    <input type="number" onkeyup="calcMode3()" id="goal_interval_amount" name="goal_interval_amount" placeholder="How much you will save?" required />
                </div>
            </div>
        </div>
        <h4>How frequently will you save?</h4>
        <div class="search_container">
            <div class="search_holder">
                <select class="field" onchange="calcMode3()" id="interval_unit" name="interval_unit" required>
                    <option value="daily">Daily</option>
                    <option value="weekly">Weekly(7 days)</option>
                    <option value="monthly">Monthly(30 days)</option>
                    <option value="yearly">Yearly(365 days)</option>
                </select>
            </div>
        </div>
        <h4>Totally you will save:</h4>
        <div class="search_container">
            <div class="search_holder">
                <div class="field">
                    <input type="text" id="total_goal_amount" name="total_goal_amount" placeholder="You will save" disabled required />
                </div>
            </div>
        </div>
        <p onclick="calcMode3()"><b>Click to calc</b></p>
        <button type="submit" name="submit" class="btn stroke center"><i class="bx bx-plus-medical"></i> Create Goal</button>
    </form>
</section>
        <?php
        break;
    default:
        header('location: saving.php');
        break;
}
?>

<!-- Form Section Ends -->

<br><br><br><br><br><br>
</div>