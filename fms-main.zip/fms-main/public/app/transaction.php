<?php
include "db/conn.php";

$user_income_sum_query = mysqli_query($connection, "SELECT SUM(trans_amount) as income_total FROM trans WHERE trans_user_id = $golspoh_session_user_id AND trans_type = 'income'");
$user_income_sum_row = mysqli_fetch_array($user_income_sum_query);
$user_income_sum = $user_income_sum_row['income_total'];

$user_expense_sum_query = mysqli_query($connection, "SELECT SUM(trans_amount) as expense_total FROM trans WHERE trans_user_id = $golspoh_session_user_id AND trans_type = 'expense'");
$user_expense_sum_row = mysqli_fetch_array($user_expense_sum_query);
$user_expense_sum = $user_expense_sum_row['expense_total'];

$user_available_balance = $user_income_sum - $user_expense_sum;

if(empty($user_income_sum)){
    $user_income_sum = 0;
}
if(empty($user_expense_sum)){
    $user_expense_sum = 0;
}



?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>Finance Management System - Transactions</title>

        <!-- Boxicons -->
        <link href="https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css" rel="stylesheet" />

        <!-- Google Fonts -->
        <!-- Livvic -->
        <link href="https://fonts.googleapis.com/css2?family=Livvic:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,900&display=swap" rel="stylesheet" />

        <!-- Style -->
        <link rel="stylesheet" href="css/style.css" />
    </head>
    <body>
        

        <?php
if(isset($_GET['page'])){
    $page = $_GET['page'];
    ?>
    <div class="bg_container">
    <div class="bg_curve small">
        <div class="profile_top">
            <div class="profile_left">
                <div class="profile_icon"></div>
                <div class="profile_content">
                    <h5>Welcome back,</h5>
                    <h3><?php echo $user_name; ?></h3>
                </div>
            </div>
            <div class="menu_icon" onclick="openNavModel()">
                <i class="bx bx-menu"></i>
            </div>
        </div>
    </div>
</div>
    
<?php
}else{
    $page = "";
    ?>
<div class="bg_container">
    <div class="bg_curve">
        <div class="profile_top">
            <div class="profile_left">
                <div class="profile_icon"></div>
                <div class="profile_content">
                    <h5>Welcome back,</h5>
                    <h3><?php echo $user_name; ?></h3>
                </div>
            </div>
            <div class="menu_icon" onclick="openNavModel()">
                <i class="bx bx-menu"></i>
            </div>
        </div>
    </div>
</div>
    <?php
}

switch ($page) {
    case 'all_transactions':
        include 'includes/transaction/all_transaction.php';
        break;
    case 'income_transactions':
        include 'includes/transaction/income_transaction.php';
        break;
    case 'expense_transactions':
        include 'includes/transaction/expense_transaction.php';
        break;
    case 'category':
        include 'includes/transaction/category.php';
        break;
    case 'form':
        include 'includes/transaction/form.php';
        break;
    default:
        ?>

        <!-- Balance Starts -->
        <section class="balance_containner">
            <div class="designs_container">
                <div class="rings_container">
                    <div class="ring_item"></div>
                    <div class="ring_item"></div>
                    <div class="ring_item"></div>
                    <i class="bx bx-money"></i>
                </div>
                <div class="curves"></div>
            </div>
            <div class="content_continer">
                <p>Available Balance</p>
                <h1><?php echo $user_currency.$user_available_balance; ?></h1>
                <div class="red_green_container">
                    <a href="transaction.php?page=expense_transactions">
                        <div class="box red">
                            <p><i class="bx bxs-up-arrow-circle"></i> Expense</p>
                            <h2><?php echo $user_currency.$user_expense_sum; ?></h2>
                        </div>
                    </a>
                    <a href="transaction.php?page=income_transactions">
                        <div class="box green">
                            <p><i class="bx bxs-down-arrow-circle"></i> Income</p>
                            <h2><?php echo $user_currency.$user_income_sum; ?></h2>
                        </div>
                    </a>
                </div>
            </div>
        </section>
        <!-- Balance Ends -->
        
        <!-- List Starts -->
        <div class="big_body_holder">
        <section class="txn_container">
                <div class="txn_heading">
                    <h3>Recent Transaction</h3>
                    <a href="transaction.php?page=all_transactions">
                        <p>See More <i class="bx bxs-right-arrow-circle"></i></p>
                    </a>
                </div>
                <div class="txn_content">
                    <?php
        $select_recent_transaction_query = "SELECT * FROM trans WHERE trans_user_id = $golspoh_session_user_id ORDER BY trans_id DESC LIMIT 5";
        $select_recent_transaction_result = mysqli_query($connection, $select_recent_transaction_query);
        while($row = mysqli_fetch_assoc($select_recent_transaction_result)){
        $trans_id = $row['trans_id'];
        $trans_user_id = $row['trans_user_id'];
        $trans_purpose = $row['trans_purpose'];
        $trans_icon_code = $row['trans_icon_code'];
        $trans_category = $row['trans_category'];
        $trans_amount = $row['trans_amount'];
        $trans_type = $row['trans_type'];
        $trans_date = $row['trans_date'];

                    ?>
                    <div class="txn_item">
                        <div class="txn_inside">
                            <div class="txn_icon">
                                <i class="<?php echo $trans_icon_code; ?>"></i>
                            </div>
                            <div class="txn_text">
                                <h4><?php echo $trans_purpose; ?></h4>
                                <span><?php echo $trans_category; ?></span>
                            </div>
                            <div class="txn_amount">
                                <?php
        if($trans_type == 'income'){
        echo "<p class='green'>+ $user_currency$trans_amount <i class='bx bxs-down-arrow-circle'></i></p>";
        }else{
        echo "<p class='red'>- $user_currency$trans_amount <i class='bx bxs-up-arrow-circle'></i></p>";
        }
                                ?>
                                <span><?php echo $trans_date; ?></span>
                            </div>
                        </div>
                        <a href="transaction.php?page=<?php echo $page; ?>&deleteid=<?php echo $trans_id; ?>"><div class="txn_delete_btn">
                            <i class='bx bxs-trash'></i>
                        </div></a>
                    </div>
                    <?php
        }
                    ?>
                </div>
            </section>
            
            <br><br><br><br>
        </div>
        <!-- List End -->
<?php
break;
}
?>
        <!-- Add btn starts -->
        <button class="btn popupbtn filled" onclick="openPopup()"><i class="bx bx-plus-medical"></i> Add Transaction</button>
        <!-- Add btn ends -->

        <!-- Popup Model -->
        <div class="popup_model" id="popupModel">
            <div class="popup_container">
                <div class="popup_container_inside">
                    <p>Choose the category</p>
                    <div class="category_container">
                        <a href="transaction.php?page=category&type=expense">
                            <div class="category_item red"><i class="bx bxs-up-arrow-circle"></i> Expense</div>
                        </a>
                        <a href="transaction.php?page=category&type=income">
                            <div class="category_item green"><i class="bx bxs-down-arrow-circle"></i> Income</div>
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <?php
include "includes/nav.php";
        ?>
<!-- Filter Model Starts -->
<div class="filter_model" id="filterModel">
    <div class="filter_container">
        <div class="filter_container_inside">
            <p>Choose the dates</p>
            <?php
if(isset($_POST['filtertxn'])){
    $filter_from = date("d-m-Y", strtotime($_POST['fromdate']));
    $filter_to = date("d-m-Y", strtotime($_POST['todate']));

    $filter_from = mysqli_real_escape_string($connection, $filter_from);
    $filter_to = mysqli_real_escape_string($connection, $filter_to);

    header('location: transaction.php?page='. $page .'&filterfrom='.$filter_from.'&filterto='.$filter_to);
}
            ?>
            <form action="transaction.php?page=<?php echo $page; ?>" method="post">
                <div class="filter_date_container">
                    <div class="date_picker">
                        <div class="icon"><i class="bx bxs-calendar"></i>From</div>
                        <div class="content">
                            <input name="fromdate" type="date" value="<?php echo date('Y-m-d'); ?>" max="<?php echo date('Y-m-d'); ?>" />
                        </div>
                    </div>
                    <div class="date_picker">
                        <div class="icon"><i class="bx bxs-calendar"></i>To</div>
                        <div class="content">
                            <input name="todate" type="date" value="<?php echo date('Y-m-d'); ?>" max="<?php echo date('Y-m-d'); ?>" />
                        </div>
                    </div>
                </div>
                <button name="filtertxn" type="submit" class="btn center filter_btn filled"><i class="bx bxs-filter-alt"></i> Filter</button>
            </form>
            <a href="transaction.php?page=<?php echo $page; ?>" style="color:red;">Clear Filter</a>
        </div>
    </div>
</div>
<!-- Filter Model Ends -->

        
<?php
if(isset($_GET['deleteid'])){
    $txn_delete_id = $_GET['deleteid'];

    $txn_delete_id = mysqli_real_escape_string($connection, $txn_delete_id);

    $delete_txn_query = "DELETE FROM trans WHERE trans_id = $txn_delete_id AND trans_user_id = $golspoh_session_user_id";
    $delete_txn_result = mysqli_query($connection, $delete_txn_query);

    header('location: transaction.php?page='.$page);
}
?>
        <script src="js/script.js"></script>
    </body>
</html>
