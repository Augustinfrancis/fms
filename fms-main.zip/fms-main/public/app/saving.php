<?php
include "db/conn.php";

$sum_saving_query = mysqli_query($connection, "SELECT SUM(savings_history_amount) as savings_amount_total FROM savings_history WHERE savings_history_user_id = $golspoh_session_user_id");
$sum_saving_query_row = mysqli_fetch_array($sum_saving_query);
$sum_saving = $sum_saving_query_row['savings_amount_total'];

if(empty($sum_saving)){
    $sum_saving = 0;
}

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>Finance Management System - Savings</title>

        <!-- Fontawesome -->
        <!-- <link rel="stylesheet" href="../../fontawesome/css/all.min.css" /> -->

        <!-- Boxicons -->
        <link href="https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css" rel="stylesheet" />

        <!-- Google Fonts -->
        <!-- Livvic -->
        <link href="https://fonts.googleapis.com/css2?family=Livvic:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,900&display=swap" rel="stylesheet" />

        <!-- Style -->
        <link rel="stylesheet" href="css/style.css" />
    </head>
    <body>
    <?php
if(isset($_GET['page'])){
    $page = $_GET['page'];
?>
<div class="bg_container">
    <div class="bg_curve small">
        <div class="profile_top">
            <div class="profile_left">
                <div class="profile_icon"></div>
                <div class="profile_content">
                    <h5>Welcome back,</h5>
                    <h3><?php echo $user_name; ?></h3>
                </div>
            </div>
            <div class="menu_icon" onclick="openNavModel()">
                <i class="bx bx-menu"></i>
            </div>
        </div>
    </div>
</div>
<?php
}else{
    $page = "";
        ?>
        <div class="bg_container">
            <div class="bg_curve">
                <div class="profile_top">
                    <div class="profile_left">
                        <div class="profile_icon"></div>
                        <div class="profile_content">
                            <h5>Welcome back,</h5>
                            <h3><?php echo $user_name; ?></h3>
                        </div>
                    </div>
                    <div class="menu_icon" onclick="openNavModel()">
                        <i class="bx bx-menu"></i>
                    </div>
                </div>
            </div>
        </div>
        <?php
}

switch ($page) {
    case 'add_custom':
        include "includes/saving/add_custom.php";
        break;
    case 'all_savings':
        include "includes/saving/all_savings.php";
        break;
    case 'savings_type':
        include "includes/saving/savings_type.php";
        break;
    case 'savings_form':
        include "includes/saving/savings_form.php";
        break;
    default:
    if(isset($_GET['delete_saving'])){
        $delete_saving_id = $_GET['delete_saving'];
    
        $delete_saving_query = "DELETE FROM savings_history WHERE savings_history_id = $delete_saving_id AND savings_history_user_id = $golspoh_session_user_id";
        $delete_saving_result = mysqli_query($connection, $delete_saving_query);
    
        header('location: saving.php');
    }
?>
        <!-- Balance Starts -->
        <section class="balance_containner" style="height: 150px">
            <div class="designs_container">
                <div class="rings_container">
                    <div class="ring_item"></div>
                    <div class="ring_item"></div>
                    <div class="ring_item"></div>
                    <i class="bx bx-money"></i>
                </div>
                <div class="curves"></div>
            </div>
            <div class="content_continer">
                <p>Total Savings</p>
                <h1><?php echo $user_currency.$sum_saving; ?></h1>
            </div>
        </section>
        <!-- Balance Ends -->
        <div class="med_body_holder">
        <!-- List Starts -->
        <section class="txn_container">
            <div class="txn_heading">
                <h3>Recent Savings</h3>
                <a href="saving.php?page=all_savings">
                    <p>See More <i class="bx bxs-right-arrow-circle"></i></p>
                </a>
            </div>
            <div class="txn_slider" style="overflow:hidden;">
                <?php
$select_recent_savings_query = "SELECT * FROM savings_history WHERE savings_history_user_id = $golspoh_session_user_id ORDER BY savings_history_id DESC LIMIT 10";
$select_recent_savings_result = mysqli_query($connection, $select_recent_savings_query);
while($row = mysqli_fetch_assoc($select_recent_savings_result)){
    $savings_history_id = $row['savings_history_id'];
    $savings_history_amount = $row['savings_history_amount'];
    $savings_history_title = $row['savings_history_title'];
    $savings_history_category = $row['savings_history_category'];
    $savings_history_date = $row['savings_history_date'];
                ?>
                    <div class="txn_slider_item edge">
                        <div class="txn_slider_item_inside">
                            <h4><?php echo $savings_history_title; ?></h4>
                            <p class="green"><?php echo $user_currency.$savings_history_amount; ?></p>
                            <span><?php echo $savings_history_date; ?></span>
                        </div>
                        <a href="saving.php?delete_saving=<?php echo $savings_history_id; ?>">
                        <div class="credit_delete_btn">
                            <i class='bx bxs-trash'></i>
                        </div>
                        </a>
                    </div>
                <?php
}
                ?>
            </div>
            <div class="txn_heading">
                <h3>Savings Dues - <span>₹2000</span></h3>
            </div>
            <div class="txn_slider">
                <?php
$select_all_saving_goals_query = "SELECT * FROM savings WHERE savings_user_id = $golspoh_session_user_id";
$select_all_saving_goals_result = mysqli_query($connection, $select_all_saving_goals_query);
while($row = mysqli_fetch_assoc($select_all_saving_goals_result)){
    $savings_id = $row['savings_id'];
    $savings_amount = $row['savings_amount'];
    $savings_amount_interval = $row['savings_amount_interval'];
    $savings_interval_unit = $row['savings_interval_unit'];
    $savings_title = $row['savings_title'];
    $savings_category = $row['savings_category'];
    $savings_date = $row['savings_date'];
    $savings_start_date = $row['savings_start_date'];
    $savings_end_date = $row['savings_end_date'];

    // $select_all_goal_record_query = "SELECT * FROM savings_history WHERE savings_history_user_id = $golspoh_session_user_id AND savings_history_goal_id = $savings_id";
    // $select_all_goal_record_result = mysqli_query($connection, $select_all_goal_record_query);
    // while($row = mysqli_fetch_assoc($select_all_goal_record_result)){
    //     $savings_history_id = $row['savings_history_id'];
    //     $savings_history_amount = $row['savings_history_amount'];
    //     $savings_history_title = $row['savings_history_title'];
    //     $savings_history_category = $row['savings_history_category'];
    //     $savings_history_date = $row['savings_history_date'];
    // }
    
    // if($savings_category == "52-week challenge"){

    // }
}
                ?>
                <a href="#">
                    <div class="txn_slider_item circle" onclick="opensavingModel(1, 2, 1000, '05/12/2021')">
                        <div class="txn_slider_item_inside">
                            <h4>Bike</h4>
                            <p class="green">₹2000</p>
                            <span>09/05/2021</span>
                        </div>
                    </div>
                </a>
                <a href="#">
                    <div class="txn_slider_item circle" onclick="opensavingModel(1, 2, 2000, '05/12/2021')">
                        <div class="txn_slider_item_inside">
                            <h4>Bike</h4>
                            <p class="green">₹2000</p>
                            <span>09/05/2021</span>
                        </div>
                    </div>
                </a>
                <a href="#">
                    <div class="txn_slider_item circle">
                        <div class="txn_slider_item_inside">
                            <h4>Bike</h4>
                            <p class="green">₹2000</p>
                            <span>09/05/2021</span>
                        </div>
                    </div>
                </a>
                <a href="#">
                    <div class="txn_slider_item circle">
                        <div class="txn_slider_item_inside">
                            <h4>Bike</h4>
                            <p class="green">₹2000</p>
                            <span>09/05/2021</span>
                        </div>
                    </div>
                </a>
                <a href="#">
                    <div class="txn_slider_item circle">
                        <div class="txn_slider_item_inside">
                            <h4>Bike</h4>
                            <p class="green">₹2000</p>
                            <span>09/05/2021</span>
                        </div>
                    </div>
                </a>
                <a href="#">
                    <div class="txn_slider_item circle">
                        <div class="txn_slider_item_inside">
                            <h4>Bike</h4>
                            <p class="green">₹2000</p>
                            <span>09/05/2021</span>
                        </div>
                    </div>
                </a>
                <a href="#">
                    <div class="txn_slider_item circle">
                        <div class="txn_slider_item_inside">
                            <h4>Bike</h4>
                            <p class="green">₹2000</p>
                            <span>09/05/2021</span>
                        </div>
                    </div>
                </a>
                <a href="#">
                    <div class="txn_slider_item circle">
                        <div class="txn_slider_item_inside">
                            <h4>Bike</h4>
                            <p class="green">₹2000</p>
                            <span>09/05/2021</span>
                        </div>
                    </div>
                </a>
            </div>
            <div class="txn_heading">
                <h3>Saving Goals - <span>₹2000</span></h3>
                <!-- <a href="transaction.html">
                    <p>See More <i class="bx bxs-right-arrow-circle"></i></p>
                </a> -->
            </div>
            <div class="txn_progress">
                <?php
$select_all_savings_challenge_query = "SELECT * FROM savings WHERE savings_category = '52-week Challenge' OR savings_category = 'Target Amount Challenge' OR savings_category = 'Target Date challenge' AND savings_user_id = $golspoh_session_user_id";
$select_all_savings_challenge_result = mysqli_query($connection, $select_all_savings_challenge_query);
while($row = mysqli_fetch_assoc($select_all_savings_challenge_result)){
    $savings_id = $row['savings_id'];
    $savings_amount = $row['savings_amount'];
    $savings_amount_interval = $row['savings_amount_interval'];
    $savings_title = $row['savings_title'];
    $savings_category = $row['savings_category'];
    $savings_date = $row['savings_date'];
    $savings_start_date = $row['savings_start_date'];
    $savings_end_date = $row['savings_end_date'];

    // $calc_saved_goal_amount_query = mysqli_query($connection, "SELECT SUM(savings_history_amount) as goal_saved_sum FROM savings_history WHERE savings_history_user_id = $golspoh_session_user_id AND savings_history_goal_id = $savings_id");
    // $calc_saved_goal_amount_query_row = mysqli_query($calc_saved_goal_amount_query);
    // $sum_saved_goal = $calc_saved_goal_amount_query_row['goal_saved_sum'];

    // if($sum_saved_goal == 0){
        $goal_percent = 0;
    // }else{
    //     $goal_percent = floor(($sum_saved_goal / $savings_amount) * 100);
    // }    

                ?>
                <a href="#">
                    <div class="txn_progress_container">
                        <div class="txn_progress_inside">
                            <div class="txn_progress_split">
                                <h1><?php echo $savings_title; ?></h1>
                                <p><?php echo $goal_percent; ?>%</p>
                            </div>
                            <div class="txn_progress_split">
                                <div class="txn_progress_target">
                                    <span>₹0</span>
                                    <span><?php echo $user_currency.$savings_amount; ?></span>
                                </div>
                                <div class="txn_progress_bar">
                                    <div class="txn_progress_bar_fill" style="width: 20%">
                                        <span><?php echo $user_currency.$sum_saved_goal; ?></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </a>
                <?php
}
                ?>
            </div>
        </section>
        <!-- List End -->
        </div>
        <?php
break;
}
        ?>
        <!-- Add btn starts -->
        <button class="btn popupbtn filled" onclick="openPopup()"><i class="bx bx-plus-medical"></i> Add Savings</button>
        <!-- Add btn ends -->

        <!-- Savings Model -->
        <div class="saving_model" id="savingModel">
            <div class="saving_container">
                <div class="saving_container_inside">
                    <p>Add to Savings</p>
                    <p id="savingsDay">(Day 0)</p>
                    <div class="savings_container_info">
                        <h4>Amount</h4>
                        <p id="savingsAmount">₹0</p>
                    </div>
                    <div class="savings_container_info">
                        <h4>Date</h4>
                        <p id="savingsDate">00/00/0000</p>
                    </div>
                    <a id="savingsLink">
                        <button class="btn center filled"><i class="bx bx-plus-medical"></i> Add Money</button>
                    </a>
                </div>
            </div>
        </div>

        <!-- Popup Model -->
        <div class="popup_model" id="popupModel">
            <div class="popup_container">
                <div class="popup_container_inside">
                    <p>Choose the Type</p>
                    <a href="saving.php?page=add_custom">
                        <button style="width: 60%" class="btn center filled"><i class="bx bx-plus-medical"></i> Custom Saving</button>
                    </a>
                    <a href="saving.php?page=savings_type">
                        <button style="width: 60%" class="btn center filled"><i class="bx bx-plus-medical"></i> Savings Goal</button>
                    </a>
                </div>
            </div>
        </div>

        <!-- Popup Model -->
        <div class="info_model" id="infoModel">
            <div class="info_container">
                <div class="info_container_inside">
                    <h3 id="info_heading"></h3>
                    <p id="info_para"></p>
                </div>
            </div>
        </div>
        <?php
include "includes/nav.php";
?>
<!-- Filter Model Starts -->
<div class="filter_model" id="filterModel">
    <div class="filter_container">
        <div class="filter_container_inside">
            <p>Choose the dates</p>
            <?php
if(isset($_POST['filtertxn'])){
    $filter_from = date("d-m-Y", strtotime($_POST['fromdate']));
    $filter_to = date("d-m-Y", strtotime($_POST['todate']));

    $filter_from = mysqli_real_escape_string($connection, $filter_from);
    $filter_to = mysqli_real_escape_string($connection, $filter_to);

    header('location: saving.php?page='. $page .'&filterfrom='.$filter_from.'&filterto='.$filter_to);
}
            ?>
            <form action="saving.php?page=<?php echo $page; ?>" method="post">
                <div class="filter_date_container">
                    <div class="date_picker">
                        <div class="icon"><i class="bx bxs-calendar"></i>From</div>
                        <div class="content">
                            <input name="fromdate" type="date" value="<?php echo date('Y-m-d'); ?>" max="<?php echo date('Y-m-d'); ?>" />
                        </div>
                    </div>
                    <div class="date_picker">
                        <div class="icon"><i class="bx bxs-calendar"></i>To</div>
                        <div class="content">
                            <input name="todate" type="date" value="<?php echo date('Y-m-d'); ?>" max="<?php echo date('Y-m-d'); ?>" />
                        </div>
                    </div>
                </div>
                <button name="filtertxn" type="submit" class="btn center filter_btn filled"><i class="bx bxs-filter-alt"></i> Filter</button>
            </form>
            <a href="saving.php?page=<?php echo $page; ?>" style="color:red;">Clear Filter</a>
        </div>
    </div>
</div>
<!-- Filter Model Ends -->
        <script src="js/script.js"></script>
    </body>
</html>
